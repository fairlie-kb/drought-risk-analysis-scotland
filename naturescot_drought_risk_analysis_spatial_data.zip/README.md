# Projected drought risk in Scotland, 2021-2040
---

This dataset consists of a set of 24 .tif files showing past or future extreme drought risk in Scotland. These were produced as part of a NatureScot study on 
changing drought risk in Scotland by 2040. The .tifs are derived from observed or modelled climate data, with drought risk calculated using the Standardised
Precipitation Evapotransipiration Index (SPEI), as described in detail in the methodology. 

## Description of the data and file structure

Note that .tifs do not retain symbology, so the colours assigned to cells when the data are opened are random and meaningless. 

Naming convention: naturescot_drought_[events/months]_[modelagreement/observations/projected]_[change/actual]_[seasonal/total]

- events/months: the metric being measured, whether extreme drought events or extreme drought months.
    - extreme drought months = any month with an SPEI value ≤ -2
    - extreme drought events = one or more months with a continuous SPEI of ≤ -2
- modelagreement/observations/projected: type of data
    - model agreement = a measure of error when combining the 12 members of the climate model (climate models come in multiple runs, known as members, which have to be combined together). The model agreement datasets show how many of the 12 members agree with the sign of the median, ie, agree with an increase or decrease in extreme drought.
    - observations = datasets based on observed data, derived from the HADUK-Grid Observational dataset
    - projected = datasets based on modelled data, derived from the UKCP18 climate model
- change/actual: is the dataset calculated change from baseline, or actual values
    - change = only for projected datasets - change calculated from the baseline (1981-2001) to the future (2021-2040)
    - actual = observed, model agreement, and some projected datasets - actual values, not change from baseline
- seasonal/total: calculated by season, or annually
    - seasonal = separated by spring (March/April/May), summer (June/July/August), autumn (September/October/November), winter (December/January/February). Only extreme drought months, not events, as events can span multiple seasons
    - total = calculated annually

## Sharing/Access information

Each .tif has full metadata including licencing information. 
All data are available under an Open Government Licence: https://www.nationalarchives.gov.uk/doc/open-government-licence/version/3/
NatureScot should be acknowledged for any use.

Links to other publicly accessible locations of the data:
  * https://opendata.nature.scot/

Data was derived from the following sources:
  * UKCP18 https://www.metoffice.gov.uk/research/approach/collaboration/ukcp
  * HadUK-Grid https://www.metoffice.gov.uk/research/climate/maps-and-data/data/haduk-grid/haduk-grid