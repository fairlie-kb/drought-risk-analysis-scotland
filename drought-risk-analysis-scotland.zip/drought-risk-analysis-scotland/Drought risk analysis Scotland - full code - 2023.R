

# Scotland Drought Risk Analysis
# Fairlie Kirkpatrick Baird
# 09-11-2020
#
# Wetlands Vulnerability Project
# NatureScot Graduate Placement, Freshwater and Wetlands Group


# ----------------------------------------------------------------------------


# This code calculates likely changes to the risk of extreme drought in Scotland
# by 2040, using the drought index Standardized Precipitation-Evapotranspiration
# Index (SPEI). Input data is observed temperature and precipitation from the
# HADUK-Grid observational dataset, and modelled temperature and precipitation
# data from the UKCP18. 
#
# A full description of the project and methodology can be
# found in: Kirkpatrick Baird, F., Stubbs Partridge, J. & Spray, D. 2020. 
# Anticipating and mitigating projected climate-driven increases in extreme 
# drought in Scotland, 2021-2040. Scottish Natural Heritage Research Report.


# ----------------------------------------------------------------------------


rm(list=ls())

#Set working directory to script location
setwd(paste0(dirname(rstudioapi::getSourceEditorContext()$path)))

#Load packages
library(reshape2) #melt
library(SPEI) #SPEI
library(rgdal) #geospatial
library(TSstudio) #ts_reshape
library(qmap) #quantile mapping
library(tidyverse)
library(pbapply)

#Citations
citation(package = "SPEI")
citation(package = "qmap")


################################# Create functions #############################

## Reformat the raw data

reformat <- function(prcp, tas){
  
  #Remove rows with year and month, and the header data, and make -- = NA
  prcp <- prcp[-seq(63, NROW(prcp), by = 63-1),]
  prcp <- prcp[-c(1),]
  prcp$V1[prcp$V1 == "--"] <- "NA"
  
  tas <- tas[-seq(63, NROW(tas), by = 63-1),]
  tas <- tas[-c(1),]
  tas$V1[tas$V1 == "--"] <- "NA"
  
  #Divide by year and month
  prcp <- split(prcp, (as.numeric(rownames(prcp)) - 1) 
                  %/% 62)
  tas <- split(tas, (as.numeric(rownames(tas)) - 1) 
                 %/% 62)
  
  #Make the top row into the col names and then remove it
  prcp <- lapply(prcp, function(x) {
    colnames(x) <- x[1,]
    x[-1,]
  })
  tas<-lapply(tas, function(x) {
    colnames(x) <- x[1,]
    x[-1,]
  })
  
  #Melt each element of the list to a combined long form dataframe
  prcp<-melt(prcp, id.vars="NA")
  tas<-melt(tas, id.vars="NA")
  
  #Make the factors into numerics
  prcp$"NA" = as.numeric(as.character(prcp$"NA"))
  prcp$variable = as.numeric(as.character(prcp$variable))
  
  tas$"NA" = as.numeric(as.character(tas$"NA"))
  tas$variable = as.numeric(as.character(tas$variable))
  
  #Make list number column (L1) numeric
  prcp$L1<-as.numeric(as.character(prcp$L1))
  tas$L1<-as.numeric(as.character(tas$L1))
  
  #Create month number column
  prcp$month<-rep(c(12, 1:11), each=3120,length.out=2249520)
  tas$month<-rep(c(12, 1:11), each=3120,length.out=2249520)
  
  #Create year column
  prcp$year<-c(rep(1980,3120),rep(1981:2040, each = 12*3120))
  tas$year<-c(rep(1980,3120),rep(1981:2040, each = 12*3120))
  
  #Remove L1 column
  prcp<-prcp[-c(4)]
  tas<-tas[-c(4)]
  
  #Rename the columns
  prcp<-rename(prcp,"northing"="NA","easting"="variable","prcp"="value")
  tas<-rename(tas,"northing"="NA","easting"="variable","tas"="value")
  
  #Merge temp and prcp
  mod<-prcp
  mod$tas<-tas$tas
  
  #Multiply prcp by # of days in the month to get monthly totals
  mod<-transform(mod, prcp=
                    ifelse(month %in% c(1,3,5,7,8,10,12),prcp*31,
                           ifelse(month %in% c(4,6,9,11),prcp*30,
                                  ifelse(month %in% c(2) & year %in% c(1984,1988,1992,1996,2000,2004,2008,
                                                                       2012,2016,2020,2024,2028,2032,2036,
                                                                       2040), 
                                         prcp*28, prcp*29))))
  
  #Remove 1980 to start ref period at 1981
  mod<-mod[-c(1:3120),]
}



## Transform BNG to lat/lon

lat_calc<-function(bng){
  
  #Define coordinate reference systems
  ukgrid <- "+init=epsg:27700"
  latlong <- "+init=epsg:4326"
  
  #Create coordinates variable
  coords <- cbind(easting = as.numeric(bng$easting),
                  northing = as.numeric(bng$northing))
  
  #Create SpatialPointsDataFrame
  sp <- SpatialPointsDataFrame(coords,
                               data = bng,
                               proj4string = CRS("+init=epsg:27700"))
  
  #Convert
  ll<-spTransform(sp, CRS(latlong))
  
  #Replace lat, lon
  ll@data$lon <- coordinates(ll)[, 1]
  ll@data$lat <- coordinates(ll)[, 2]
  
  #Make into a dataframe
  bng<-as.data.frame(ll)
  
  #Exclude extra northing and easting column
  bng<-subset(bng, select=c(1:8))
}


## Transform lat/lon to BNG

bng_calc<-function(wgs){
  
  #Define coordinate reference systems
  ukgrid <- "+init=epsg:27700"
  latlong <- "+init=epsg:4326"
  
  #Create coordinates variable
  coords <- cbind(lon = as.numeric(wgs$lon),
                  lat = as.numeric(wgs$lat))
  
  #Create SpatialPointsDataFrame
  sp <- SpatialPointsDataFrame(coords,
                               data = wgs,
                               proj4string = CRS("+init=epsg:4326"))
  
  #Convert
  uk<-spTransform(sp, CRS(ukgrid))
  
  #Replace lat, lon
  uk@data$easting <- coordinates(uk)[, 1]
  uk@data$northing <- coordinates(uk)[, 2]
  
  #Make into a dataframe
  wgs<-as.data.frame(uk)
  
  #Exclude extra northing and easting column
  wgs<-subset(wgs, select=c(1:8))
}



## Prepare past dataset for bias correction - match observation locations with model locations 

past <- function(mod, obs) {
  
  #Subset observations to just Scotland
  obs<-subset(obs, lat>54)
  
  #Subset model output to baseline period (for the bias correction - different to baseline for SPEI)
  mod<-subset(mod, year < 2001)
  
  #Add an ID column to the obs, by month/year
  obs$obs_ID<-rep(1:821, times = 240)
  
  #Add empty obs ID and distance (between obs points and nearest model point) columns to mod
  mod$obs_ID<-rep(NA, times = 748800)
  mod$distance<-rep(NA, times = 748800)
  
  #Rename to differentiate between mod and obs columns
  mod<-rename(mod,"lat_mod"="lat","lon_mod"="lon","prcp_mod"="prcp", "tas_mod"="tas")
  obs<-rename(obs,"lat_obs"="lat","lon_obs"="lon","prcp_obs"="prcp", "tas_obs"="tas")
  
  #Divide by month and year to correctly match points in time as well as space
  obs<-split(obs, list(obs$month, obs$year))
  mod<-split(mod, list(mod$month, mod$year))
  
  #Find nearest neighbour coordinates for Jan 1981
  for(i in 1:length(mod)){
    y<-obs[[i]]
    x<-mod[[i]]
    z<-as.data.frame(RANN::nn2(y[,c(1,2)],x[,c(8,7)],k=1)); x[,9] <- y[x[, 9], 7]
    mod[[i]]$obs_ID<-z$nn.idx
    mod[[i]]$distance<-z$nn.dists
  }
  
  #Use the coordinates from Jan 1981 to match obs with mod for the rest of the years
  mod<-mapply(function(x,y){
    merge(x, y, by = c("obs_ID", "month","year"), all.x=T, all.y=F)
    }, x=mod, y=obs, SIMPLIFY = F)
  
  #Combine list elements into one dataframe
  mod<-do.call(rbind,mod)
}


## Bias calculation

bias <- function (base, future) {
  
  #Format data
  base$BNG<-paste(base$easting.x,",",base$northing.x)
  future$BNG<-paste(future$easting,",",future$northing)
  
  base_obs<-select(base, month, year, prcp_obs, tas_obs, BNG, easting.x, northing.x, 
                   lon_mod, lat_mod)
  base_obs$type<-rep("obs")
  base_obs<-rename(base_obs,"easting" = "easting.x","northing" = "northing.x", 
                   "lat" = "lat_mod", "lon" = "lon_mod")
  
  
  future_mod<-select(future, month, year, prcp, tas, BNG, easting, northing, 
                     lon, lat)
  future_mod$type<-rep("mod")
  future_mod<-rename(future_mod, "prcp_mod" = "prcp", "tas_mod" = "tas")
  
  dl_obs <- base_obs %>% split(., .$BNG)
  dl_mod <- future_mod %>% split(., .$BNG)
  
  #Create key to BNG
  gridkey <- unique(future_mod$BNG)
  gridkey <- as.data.frame(gridkey)
  
  #Fit function
  dlFit_prcp <- 
    
    pblapply(as.character(gridkey$gridkey), function(y) { 
      
      fitQmapRQUANT(obs = dl_obs[[y]]$prcp_obs,
                    mod = dl_mod[[y]]$prcp_mod, 
                    wet.day = TRUE, qstep = 1/9,
                    type = "linear")
      
    }) %>% setNames(as.character(gridkey$gridkey))
  
  #Apply correction
  dl_prcp <- 
    
    pblapply(as.character(gridkey$gridkey), function(y) { 
      
      tryCatch( {
        
        rquant <- doQmap(dl_mod[[y]]$prcp_mod, dlFit_prcp[[y]])
        dl_mod[[y]] %>% mutate(pmod_rquant = rquant)
        
      }, error = function(e) NULL )
      
    })
  
  #Format data
  prcp <- 
    dl_prcp %>% 
    bind_rows() %>% 
    left_join(
      dl_obs %>% 
        bind_rows() %>% 
        select(BNG, year, month)
    ) %>%
    select(-type)
  
  #Fit function
  dlFit_tas <- 
    
    pblapply(as.character(gridkey$gridkey), function(y) { 
      
      fitQmapRQUANT(obs = dl_obs[[y]]$tas_obs,
                    mod = dl_mod[[y]]$tas_mod, 
                    wet.day = FALSE, qstep = 1/9,
                    type = "linear")
      
    }) %>% setNames(as.character(gridkey$gridkey))
  
  #Apply correction
  dl_tas <- 
    
    pblapply(as.character(gridkey$gridkey), function(y) { 
      
      tryCatch( {
        
        rquant <- doQmap(dl_mod[[y]]$tas_mod, dlFit_tas[[y]])
        dl_mod[[y]] %>% mutate(tmod_rquant = rquant)
        
      }, error = function(e) NULL )
      
    })
  
  #Format data
  tas <- 
    dl_tas %>% 
    bind_rows() %>% 
    left_join(
      dl_obs %>% 
        bind_rows() %>% 
        select(BNG, year, month)
    ) %>%
    select(-type)
  
  #Combine datasets
  base2 <- prcp
  base2$tas_correct <- tas$tmod_rquant
  
  base2 <- rename(base2, "prcp_correct" = "pmod_rquant")
  
}


## SPEI calculation

spei_calc<- function(climbal) {
  
  #Calculate PET
  climbal<-lapply(climbal, function(x)
    transform(x, pet = thornthwaite(x[["tas_correct"]],first(x[["lat"]]))))
  
  #Calculate climactic water balance
  climbal<-lapply(climbal, function(x)
    transform(x, bal = x[["prcp_correct"]]-x[["PET_tho"]]))
  
  #Convert each element to a time series
  climbal<-lapply(climbal, function(x)
    ts(x, end=c(2040,12), frequency = 12))
  
  #Calculate SPEI using a 6 month time step and 1981-2001 reference period
  climbal<-lapply(climbal, function(x)
    spei(x[,"bal"], 6, ref.start = c(1981,6), ref.end = c(2001,5)))
}


## Calculate number of drought months and drought events by season

#Split into past/present/future
years <- function(spei){

  #Extract SPEI values, month and year
  spei<-subset(rename(melt(lapply(spei, function(x){
    x<-x$fitted
    x<-ts_reshape(x, type = "long")
  }), id.vars=c("year","month")),
  "spei"="value", "BNG"="L1"), select = -variable)
  
  #Add time period column with June 1981 - May 2001 as the baseline
  spei<-transform(spei, period=ifelse(year < 2002, "past", 
                               ifelse(year > 2001 & year < 2021, "present","future")))
  spei$period[spei$year==2001 & spei$month > 5] <- "present"
  
  #Remove the NA rows in 1981 to simplify
  spei<-spei[!(spei$year == 1981 & spei$month == 1:5 ),] 
  
  #Split into past/present/future
  spei<-split(spei, spei$period)
  
}

#Create df with SPEI values for the obs
years_obs <- function(spei){
  
  #Extract SPEI values, month and year
  spei<-subset(rename(melt(lapply(spei, function(x){
    x<-x$fitted
    x<-ts_reshape(x, type = "long")
  }), id.vars=c("year","month")),
  "spei"="value", "BNG"="L1"), select = -variable)
  
  #Remove the NA rows in 1981 to simplify
  spei<-spei[!(spei$year == 1981 & spei$month == 1:5 ),] 
  
}


#Split by season (model)
seasons <- function(spei){
  
  #Extract SPEI values, month and year
  spei<-subset(rename(melt(lapply(spei, function(x){
    x<-x$fitted
    x<-ts_reshape(x, type = "long")
  }), id.vars=c("year","month")),
  "spei"="value", "BNG"="L1"), select = -variable)
  
  #Add time period column with June 1981 - May 2001 as the baseline
  spei<-transform(spei, period=ifelse(year < 2002, "past", 
                                      ifelse(year > 2001 & year < 2021, "present","future")))
  spei$period[spei$year==2001 & spei$month > 5] <- "present"
  
  #Remove the NA rows in 1981 to simplify
  spei<-spei[!(spei$year == 1981 & spei$month == 1:5 ),] 
  
  #Add season column
  spei<-transform(spei, season=ifelse(month %in% c(3,4,5), "spring",
                                  ifelse(month %in% c(6,7,8), "summer", 
                                         ifelse(month %in% c(9,10,11),"autumn", "winter"))))
  
  #Split into past/present/future
  spei<-split(spei, spei$period)
  
  #Split by season
  spei<-lapply(spei, function(x){
    split(x, x$season)
    })
}
  

#Split by season (observations)
seasons_obs <- function(spei){
  
  #Extract SPEI values, month and year
  spei<-subset(rename(melt(lapply(spei, function(x){
    x<-x$fitted
    x<-ts_reshape(x, type = "long")
  }), id.vars=c("year","month")),
  "spei"="value", "BNG"="L1"), select = -variable)
  
  #Add season column
  spei<-transform(spei, season=ifelse(month %in% c(3,4,5), "spring",
                                      ifelse(month %in% c(6,7,8), "summer", 
                                             ifelse(month %in% c(9,10,11),"autumn", "winter"))))
  
  #Remove the NA rows in 1981 to simplify
  spei<-spei[!(spei$year == 1981 & spei$month == 1:5 ),]
  
  #Split by season
  spei<-split(spei, spei$season)

  }


#Split by period AND season
period_season <- function(spei){
  
  #Extract SPEI values, month and year
  spei<-subset(rename(melt(lapply(spei, function(x){
    x<-x$fitted
    x<-ts_reshape(x, type = "long")
  }), id.vars=c("year","month")),
  "spei"="value", "BNG"="L1"), select = -variable)
  
  #Add time period column with June 1981 - May 2001 as the baseline
  spei<-transform(spei, period=ifelse(year < 2002, "past", 
                                      ifelse(year > 2001 & year < 2021, "present","future")))
  spei$period[spei$year==2001 & spei$month > 5] <- "present"
  
  #Remove the NA rows in 1981 to simplify
  spei<-spei[!(spei$year == 1981 & spei$month == 1:5 ),] 
  
  #Add season column
  spei<-transform(spei, season=ifelse(month %in% c(3,4,5), "spring",
                                      ifelse(month %in% c(6,7,8), "summer", 
                                             ifelse(month %in% c(9,10,11),"autumn", "winter"))))
  
  #Split into past/present/future
  spei<-split(spei, list(spei$period,spei$season))

}


## Calculate number of drought months 

#For the modelled data
months_mod<- function(season){
    
  #Sum SPEI values at different thresholds for the past
  season<-season %>%
    group_by(BNG) %>%
    summarise("Extremely_dry" = sum(spei <= -2, na.rm=T), 
              "Severely_dry" = sum(spei > -2 & spei <= -1.5, na.rm=T), 
              "Moderately_dry" = sum(spei > -1.5 & spei <= -1, na.rm=T), 
              "Near_normal" = sum(spei > -1 & spei < 1, na.rm=T), 
              "Moderately_wet" = sum(spei >= 1 & spei < 1.5, na.rm=T), 
              "Very_wet" = sum(spei >= 1.5 & spei < 2, na.rm=T), 
              "Extremely_wet" = sum(spei >= 2, na.rm=T),
              "All_drought" =  sum(spei <= -1, na.rm=T),
              "All_wet" = sum(spei >= 1, na.rm=T))

  #Split location
  season<-transform(season, test=do.call(rbind, strsplit(BNG, '.', fixed=TRUE)), 
                    stringsAsFactors=F)
  
  season<-rename(season, "easting"="test.1", "northing"="test.2")
  
  #Return
  as.data.frame(season)
  
  }


#For the observed data
months_obs <- function(season){
  
  #Sum SPEI values at different thresholds for the past
  season<-season %>%
    group_by(BNG) %>%
    summarise("Extremely_dry" = sum(spei <= -2, na.rm=T), 
              "Severely_dry" = sum(spei > -2 & spei <= -1.5, na.rm=T), 
              "Moderately_dry" = sum(spei > -1.5 & spei <= -1, na.rm=T), 
              "Near_normal" = sum(spei > -1 & spei < 1, na.rm=T), 
              "Moderately_wet" = sum(spei >= 1 & spei < 1.5, na.rm=T), 
              "Very_wet" = sum(spei >= 1.5 & spei < 2, na.rm=T), 
              "Extremely_wet" = sum(spei >= 2, na.rm=T),
              "All_drought" =  sum(spei <= -1, na.rm=T),
              "All_wet" = sum(spei >= 1, na.rm=T))
  
  #Split location
  season<-transform(season, test=do.call(rbind, strsplit(BNG, ',', fixed=TRUE)), 
                    stringsAsFactors=F)
  
  season<-rename(season, "easting"="test.1", "northing"="test.2")
  
  #Return
  as.data.frame(season)
  
}
  

## Calculate actual number of drought events

#For the modelled data
events_mod <- function(year){
  
  #Split by location
  year<-split(year, year$BNG)
  
  #Count number of events below the drought threshold
  year<-melt(lapply(year, function(x){
    with(rle(x$spei <= -2), sum(lengths[values] >= 1))
  }))
  
  #Split location and rename
  year<-transform(year, test=do.call(rbind, strsplit(L1, '.', fixed=TRUE)), 
                  stringsAsFactors=F)
  
  year<-rename(year, "easting"="test.1", "northing"="test.2", "events"="value", "BNG"="L1")
}


#For the observed data
events_obs <- function(year){
  
  #Split by location
  year<-split(year, year$BNG)
  
  #Count number of events below the drought threshold
  year<-melt(lapply(year, function(x){
    with(rle(x$spei <= -2), sum(lengths[values] >= 1))
  }))
  
  #Split location and rename
  year<-transform(year, test=do.call(rbind, strsplit(L1, ',', fixed=TRUE)), 
                  stringsAsFactors=F)
  
  year<-rename(year, "easting"="test.1", "northing"="test.2", "events"="value", "BNG"="L1")
}


## Calculate actual number of drought events by season

events_season <- function(per_sea){

  per_sea<-split(per_sea, list(per_sea$year,per_sea$BNG))
  
  #Count number of events below the drought threshold
  per_sea<-melt(lapply(per_sea, function(x){
    with(rle(x$spei <= -2), sum(lengths[values] >= 1))
  }))
  
  #Split location and rename
  per_sea<-transform(per_sea, test=do.call(rbind, strsplit(L1, '.', fixed=TRUE)), 
                  stringsAsFactors=F)
  per_sea<-transform(per_sea, BNG=paste(test.2,".",test.3))
  
  #Add them all up
  per_sea<-per_sea %>%
    group_by(BNG) %>%
    summarise("events" = sum(value))
  
  #Split location and rename (again)
  per_sea$BNG<-as.character(per_sea$BNG)
  
  per_sea<-transform(per_sea, test=do.call(rbind, strsplit(BNG, '.', fixed=TRUE)), 
                  stringsAsFactors=F)
  
  per_sea<-rename(per_sea, "easting"="test.1", "northing"="test.2")
  
}



## Calculate change 

change <- function(data_past, data_future){

  #Calculate change from baseline
  past2<-subset(data_past, select = -c(BNG, easting, northing))
  future2<-subset(data_future, select = -c(BNG, easting, northing))
  change<-future2-past2
  
  #Add location
  change$BNG<-data_past$BNG
  change<-rename(transform(change, test=do.call(rbind, strsplit(BNG, '.', fixed=TRUE)), 
                         stringsAsFactors=F), "easting"="test.1", "northing"="test.2")
  
  #Return
  as.data.frame(change)

  }
  

  
## Combine the members by using the median

combine<-function(m0000,m1113,m1554,m1649,m1843,m1935,m2123,m2242,m2305,m2335,m2491,m2868){
  
  #List all members
  median <- list(m0000,m1113,m1554,m1649,m1843,m1935,
                 m2123,m2242,m2305,m2335,m2491,m2868)
  
  #Transform into long form
  median <- melt(median, id.vars="BNG")
  
  #Remove unnecessary easting/northing variables
  median <- median[!(median$variable=="easting" | median$variable=="northing"),]
  
  #Make the values numeric
  median$value <- as.numeric(median$value)
  
  #Find the median of each variable type for each location, and pivot data
  median <- 
    median %>%
    group_by(variable, BNG) %>%
    summarise(median = median(value)) %>%
    ungroup %>%
    pivot_wider(names_from = variable, values_from = median)
  
  #Create separate northing/easting columns
  median <- transform(median, test=do.call(rbind, strsplit(BNG, '.', fixed=TRUE)), 
                      stringsAsFactors=F)
  
  #Rename location columns
  median<-rename(median, "easting"="test.1", "northing"="test.2")
  
}


## Calculate model member agreement

#Months
mod_agree_months <- function(m0000, m1113, m1554, m1649, m1843, m1935, 
                      m2123, m2242, m2305, m2335, m2491, m2868, comb){
  
  #Add member ids
  m0000$member<-rep("m0000", times = 3120)
  m1113$member<-rep("m1113", times = 3120)
  m1554$member<-rep("m1554", times = 3120)
  m1649$member<-rep("m1649", times = 3120)
  m1843$member<-rep("m1843", times = 3120)
  m1935$member<-rep("m1935", times = 3120)
  m2123$member<-rep("m2123", times = 3120)
  m2242$member<-rep("m2242", times = 3120)
  m2305$member<-rep("m2305", times = 3120)
  m2335$member<-rep("m2335", times = 3120)
  m2491$member<-rep("m2491", times = 3120)
  m2868$member<-rep("m2868", times = 3120)
  
  #Combine into one dataset
  all<-rbind(m0000, m1113, m1554, m1649, m1843, m1935, 
             m2123, m2242, m2305, m2335, m2491, m2868)
  
  #Assign 1 for agreement with average sign, 0 for disagreement
  all$agree <- ifelse(comb$Extremely_dry > 0 & all$Extremely_dry > 0, 1,
                      ifelse(comb$Extremely_dry < 0 & all$Extremely_dry < 0, 1, 
                             ifelse(comb$Extremely_dry == 0 & all$Extremely_dry == 0, 1, 0)))
  
  #Split by location
  all<-split(all, all$BNG)
  
  #Add agreements
  sum<-melt(lapply(all, function(x){
    sum(x$agree)
  }))
  
  #Split location column
  sum<-transform(sum, test=do.call(rbind, strsplit(L1, '.', fixed=TRUE)), 
                 stringsAsFactors=F)
  
  sum<-rename(sum, "easting"="test.1", "northing"="test.2", "BNG"="L1","agreement"="value")
  
}

#Events
mod_agree_events <- function(m0000, m1113, m1554, m1649, m1843, m1935, 
                             m2123, m2242, m2305, m2335, m2491, m2868, comb){
  
  #Add member ids
  m0000$member<-rep("m0000", times = 3120)
  m1113$member<-rep("m1113", times = 3120)
  m1554$member<-rep("m1554", times = 3120)
  m1649$member<-rep("m1649", times = 3120)
  m1843$member<-rep("m1843", times = 3120)
  m1935$member<-rep("m1935", times = 3120)
  m2123$member<-rep("m2123", times = 3120)
  m2242$member<-rep("m2242", times = 3120)
  m2305$member<-rep("m2305", times = 3120)
  m2335$member<-rep("m2335", times = 3120)
  m2491$member<-rep("m2491", times = 3120)
  m2868$member<-rep("m2868", times = 3120)
  
  #Combine into one dataset
  all<-rbind(m0000, m1113, m1554, m1649, m1843, m1935, 
             m2123, m2242, m2305, m2335, m2491, m2868)
  
  #Assign 1 for agreement with average sign, 0 for disagreement
  all$agree <- ifelse(comb$events > 0 & all$events > 0, 1,
                      ifelse(comb$events < 0 & all$events < 0, 1, 
                             ifelse(comb$events == 0 & all$events == 0, 1, 0)))
  
  #Split by location
  all<-split(all, all$BNG)
  
  #Add agreements
  sum<-melt(lapply(all, function(x){
    sum(x$agree)
  }))
  
  #Split location column
  sum<-transform(sum, test=do.call(rbind, strsplit(L1, '.', fixed=TRUE)), 
                 stringsAsFactors=F)
  
  sum<-rename(sum, "easting"="test.1", "northing"="test.2", "BNG"="L1","agreement"="value")
  
}


## Calculate model member sd

#Months
stand_dev_months<-function(m0000,m1113,m1554,m1649,m1843,m1935,m2123,m2242,m2305,m2335,m2491,m2868){
  
  #Add member ids
  m0000$member<-rep("m0000", times = 3120)
  m1113$member<-rep("m1113", times = 3120)
  m1554$member<-rep("m1554", times = 3120)
  m1649$member<-rep("m1649", times = 3120)
  m1843$member<-rep("m1843", times = 3120)
  m1935$member<-rep("m1935", times = 3120)
  m2123$member<-rep("m2123", times = 3120)
  m2242$member<-rep("m2242", times = 3120)
  m2305$member<-rep("m2305", times = 3120)
  m2335$member<-rep("m2335", times = 3120)
  m2491$member<-rep("m2491", times = 3120)
  m2868$member<-rep("m2868", times = 3120)
  
  #Combine into one dataset
  all<-rbind(m0000, m1113, m1554, m1649, m1843, m1935, 
             m2123, m2242, m2305, m2335, m2491, m2868)
  
  #Split by location
  all<-split(all, all$BNG)
  
  #Find sd
  all_sd<-melt(lapply(all, function(x){
    sd(x$Extremely_dry)
  }))
  
  #Split location column
  all_sd<-transform(all_sd, test=do.call(rbind, strsplit(L1, '.', fixed=TRUE)), 
                    stringsAsFactors=F)
  
  all_sd<-rename(all_sd, "easting"="test.1", "northing"="test.2", "BNG"="L1","sd"="value")
  
}


#Events
stand_dev_events<-function(m0000,m1113,m1554,m1649,m1843,m1935,m2123,m2242,m2305,m2335,m2491,m2868){
  
  #Add member ids
  m0000$member<-rep("m0000", times = 3120)
  m1113$member<-rep("m1113", times = 3120)
  m1554$member<-rep("m1554", times = 3120)
  m1649$member<-rep("m1649", times = 3120)
  m1843$member<-rep("m1843", times = 3120)
  m1935$member<-rep("m1935", times = 3120)
  m2123$member<-rep("m2123", times = 3120)
  m2242$member<-rep("m2242", times = 3120)
  m2305$member<-rep("m2305", times = 3120)
  m2335$member<-rep("m2335", times = 3120)
  m2491$member<-rep("m2491", times = 3120)
  m2868$member<-rep("m2868", times = 3120)
  
  #Combine into one dataset
  all<-rbind(m0000, m1113, m1554, m1649, m1843, m1935, 
             m2123, m2242, m2305, m2335, m2491, m2868)
  
  #Split by location
  all<-split(all, all$BNG)
  
  #Find sd
  all_sd<-melt(lapply(all, function(x){
    sd(x$events)
  }))
  
  #Split location column
  all_sd<-transform(all_sd, test=do.call(rbind, strsplit(L1, '.', fixed=TRUE)), 
                    stringsAsFactors=F)
  
  all_sd<-rename(all_sd, "easting"="test.1", "northing"="test.2", "BNG"="L1","sd"="value")
  
}


######################################## Observations ###################################
  
#Import data
p_obs<-read.csv("prcp_obs_12km.csv", header=T)
t_obs<-read.csv("tas_obs_12km.csv", header=T)
  
  
## Prepare the dataset
  
#Merge temp and precipitation
obs<-p_obs
obs$tas<-t_obs$tas

#Add in BNG
obs<-bng_calc(obs)
  

## Observations SPEI

#Split datasets by location - combine BNG and use that to split by
obs$BNG<-paste(obs$easting,",",obs$northing)
obs_split<-split(obs, obs$BNG)

  
#Calculate SPEI
  
  #Calculate PET
  obs_split<-lapply(obs_split, function(x)
    transform(x, pet = thornthwaite(x[["tas"]],first(x[["lat"]]))))
  
  #Calculate climactic water balance
  obs_split<-lapply(obs_split, function(x)
    transform(x, bal = x[["prcp"]]-x[["PET_tho"]]))
  
  #Convert each element to a time series
  obs_split<-lapply(obs_split, function(x)
    ts(x, end=c(2000,12), frequency = 12))
  
  #Calculate SPEI using a 6 month time step and 1981-2000 reference period
  obs_spei<-lapply(obs_split, function(x)
    spei(x[,"bal"],6))

#Calculate number of drought months total
spei_obs_years<-years_obs(obs_spei)
months_obs_total<-months_obs(spei_obs_years)

#write.csv(months_obs_total, "C:/Users/Documents/SPEI analysis/actual files/months_obs_total.csv")

  
#Calculate number of drought months by season
spei_obs_seasons<-seasons_obs(obs_spei)
months_obs_spring<-months_obs(spei_obs_seasons[["spring"]])
months_obs_summer<-months_obs(spei_obs_seasons[["summer"]])
months_obs_autumn<-months_obs(spei_obs_seasons[["autumn"]])
months_obs_winter<-months_obs(spei_obs_seasons[["winter"]])

#write.csv(months_obs_spring, "C:/Users/Documents/SPEI analysis/actual files/months_obs_spring.csv")
#write.csv(months_obs_summer, "C:/Users/Documents/SPEI analysis/actual files/months_obs_summer.csv")
#write.csv(months_obs_autumn, "C:/Users/Documents/SPEI analysis/actual files/months_obs_autumn.csv")
#write.csv(months_obs_winter, "C:/Users/Documents/SPEI analysis/actual files/months_obs_winter.csv")
  

#Calculate number of drought events
obs_events<-events_obs(spei_obs_years)

#write.csv(obs_events, "C:/Users/Documents/SPEI analysis/actual files/events_obs_ex.csv")

#Calculate number of drought events by season
events_obs_spring<-events_obs(spei_obs_seasons[["spring"]])
events_obs_summer<-events_obs(spei_obs_seasons[["summer"]])
events_obs_autumn<-events_obs(spei_obs_seasons[["autumn"]])
events_obs_winter<-events_obs(spei_obs_seasons[["winter"]])

#write.csv(events_obs_spring, "C:/Users/Documents/SPEI analysis/actual files/events_obs_spring_ex.csv")
#write.csv(events_obs_summer, "C:/Users/Documents/SPEI analysis/actual files/events_obs_summer_ex.csv")
#write.csv(events_obs_autumn, "C:/Users/Documents/SPEI analysis/actual files/events_obs_autumn_ex.csv")
#write.csv(events_obs_winter, "C:/Users/Documents/SPEI analysis/actual files/events_obs_winter_ex.csv")


########################################## Model output 0000 #########################################
  
#Import data
p_mod_0000<-read.csv("prcp_1980_2040_mod_12km_0000.csv",
                            header=F)
t_mod_0000<-read.csv("tas_1980_2040_mod_12km_0000.csv",
                            header=F)
  
#Reformat
mod_0000<-reformat(p_mod_0000, t_mod_0000)
  
#Change coordinates
mod_0000 <- lat_calc(mod_0000)

#Calculate bias
base_0000 <- past(mod_0000, obs)
mod_0000 <- bias(base_0000, mod_0000)

#Split into datasets by location
mod_0000_split <- split(mod_0000, list(mod_0000$easting, mod_0000$northing))
  
#Calculate SPEI 
mod_0000_spei<-spei_calc(mod_0000_split)


#Calculate number of drought events
spei_y_0000<-years(mod_0000_spei)
modpast_events_0000<-events_mod(spei_y_0000[["past"]])
modpresent_events_0000<-events_mod(spei_y_0000[["present"]])
modfuture_events_0000<-events_mod(spei_y_0000[["future"]])

#Save as .csv
#write.csv(modpast_events_0000, "C:/Users/Documents/SPEI analysis/actual files/events_modpast_0000_ex.csv")
write.csv(modpresent_events_0000, "events_modpresent_0000_ex.csv")
#write.csv(modfuture_events_0000, "C:/Users/Documents/SPEI analysis/actual files/events_modfuture_0000_ex.csv")

#Calculate number of drought events by season
spei_ps_0000<-period_season(mod_0000_spei)
modpast_events_spring_0000<-events_season(spei_ps_0000[["past.spring"]])
modpast_events_summer_0000<-events_season(spei_ps_0000[["past.summer"]])
modpast_events_autumn_0000<-events_season(spei_ps_0000[["past.autumn"]])
modpast_events_winter_0000<-events_season(spei_ps_0000[["past.winter"]])

modpresent_events_spring_0000<-events_season(spei_ps_0000[["present.spring"]])
modpresent_events_summer_0000<-events_season(spei_ps_0000[["present.summer"]])
modpresent_events_autumn_0000<-events_season(spei_ps_0000[["present.autumn"]])
modpresent_events_winter_0000<-events_season(spei_ps_0000[["present.winter"]])

modfuture_events_spring_0000<-events_season(spei_ps_0000[["future.spring"]])
modfuture_events_summer_0000<-events_season(spei_ps_0000[["future.summer"]])
modfuture_events_autumn_0000<-events_season(spei_ps_0000[["future.autumn"]])
modfuture_events_winter_0000<-events_season(spei_ps_0000[["future.winter"]])

#Save as .csv
#write.csv(modpast_events_spring_0000, "C:/Users/Documents/SPEI analysis/actual files/events_modpast_spring_0000_ex.csv")
#write.csv(modpast_events_summer_0000, "C:/Users/Documents/SPEI analysis/actual files/events_modpast_summer_0000_ex.csv")
#write.csv(modpast_events_autumn_0000, "C:/Users/Documents/SPEI analysis/actual files/events_modpast_autumn_0000_ex.csv")
#write.csv(modpast_events_winter_0000, "C:/Users/Documents/SPEI analysis/actual files/events_modpast_winter_0000_ex.csv")

#write.csv(modpresent_events_spring_0000, "events_modpresent_spring_0000_ex.csv")
#write.csv(modpresent_events_summer_0000, "events_modpresent_summer_0000_ex.csv")
#write.csv(modpresent_events_autumn_0000, "events_modpresent_autumn_0000_ex.csv")
#write.csv(modpresent_events_winter_0000, "events_modpresent_winter_0000_ex.csv")

#write.csv(modfuture_events_spring_0000, "C:/Users/Documents/SPEI analysis/actual files/events_modfuture_spring_0000_ex.csv")
#write.csv(modfuture_events_summer_0000, "C:/Users/Documents/SPEI analysis/actual files/events_modfuture_summer_0000_ex.csv")
#write.csv(modfuture_events_autumn_0000, "C:/Users/Documents/SPEI analysis/actual files/events_modfuture_autumn_0000_ex.csv")
#write.csv(modfuture_events_winter_0000, "C:/Users/Documents/SPEI analysis/actual files/events_modfuture_winter_0000_ex.csv")


#Calculate number of drought months overall
modpast_months_0000<-months_mod(spei_y_0000[["past"]])
modpresent_months_0000<-months_mod(spei_y_0000[["present"]])
modfuture_months_0000<-months_mod(spei_y_0000[["future"]])

#Save as .csv
#write.csv(modpast_months_0000, "C:/Users/Documents/SPEI analysis/actual files/months_mod_actual_past_0000.csv")
#write.csv(modpresent_months_0000, "months_mod_actual_present_0000.csv")
#write.csv(modfuture_months_0000, "C:/Users/Documents/SPEI analysis/actual files/months_mod_actual_future_0000.csv")


#Calculate number of drought months
spei_s_0000<-seasons(mod_0000_spei)
modpast_months_spring_0000<-months_mod(spei_s_0000[["past"]][["spring"]])
modpast_months_summer_0000<-months_mod(spei_s_0000[["past"]][["summer"]])
modpast_months_autumn_0000<-months_mod(spei_s_0000[["past"]][["autumn"]])
modpast_months_winter_0000<-months_mod(spei_s_0000[["past"]][["winter"]])

modpresent_months_spring_0000<-months_mod(spei_s_0000[["present"]][["spring"]])
modpresent_months_summer_0000<-months_mod(spei_s_0000[["present"]][["summer"]])
modpresent_months_autumn_0000<-months_mod(spei_s_0000[["present"]][["autumn"]])
modpresent_months_winter_0000<-months_mod(spei_s_0000[["present"]][["winter"]])

modfuture_months_spring_0000<-months_mod(spei_s_0000[["future"]][["spring"]])
modfuture_months_summer_0000<-months_mod(spei_s_0000[["future"]][["summer"]])
modfuture_months_autumn_0000<-months_mod(spei_s_0000[["future"]][["autumn"]])
modfuture_months_winter_0000<-months_mod(spei_s_0000[["future"]][["winter"]])

#Save as .csv
#write.csv(modpast_months_spring_0000, "C:/Users/Documents/SPEI analysis/actual files/months_modpast_spring_0000.csv")
#write.csv(modpast_months_summer_0000, "C:/Users/Documents/SPEI analysis/actual files/months_modpast_summer_0000.csv")
#write.csv(modpast_months_autumn_0000, "C:/Users/Documents/SPEI analysis/actual files/months_modpast_autumn_0000.csv")
#write.csv(modpast_months_winter_0000, "C:/Users/Documents/SPEI analysis/actual files/months_modpast_winter_0000.csv")

#write.csv(modpresent_months_spring_0000, "months_modpresent_spring_0000.csv")
#write.csv(modpresent_months_summer_0000, "months_modpresent_summer_0000.csv")
#write.csv(modpresent_months_autumn_0000, "months_modpresent_autumn_0000.csv")
#write.csv(modpresent_months_winter_0000, "months_modpresent_winter_0000.csv")

#write.csv(modfuture_months_spring_0000, "C:/Users/Documents/SPEI analysis/actual files/months_modfuture_spring_0000.csv")
#write.csv(modfuture_months_summer_0000, "C:/Users/Documents/SPEI analysis/actual files/months_modfuture_summer_0000.csv")
#write.csv(modfuture_months_autumn_0000, "C:/Users/Documents/SPEI analysis/actual files/months_modfuture_autumn_0000.csv")
#write.csv(modfuture_months_winter_0000, "C:/Users/Documents/SPEI analysis/actual files/months_modfuture_winter_0000.csv")


#Calculate change in number of drought events
changeevents_0000<-change(modpast_events_0000, modfuture_events_0000)

#Save as .csv
#write.csv(changeevents_0000, "C:/Users/Documents/SPEI analysis/change files/changeevents_0000_ex.csv")

#Calculate change in number of drought events seasonally
changeevents_spring_0000<-change(modpast_events_spring_0000, modfuture_events_spring_0000)
changeevents_summer_0000<-change(modpast_events_summer_0000, modfuture_events_summer_0000)
changeevents_autumn_0000<-change(modpast_events_autumn_0000, modfuture_events_autumn_0000)
changeevents_winter_0000<-change(modpast_events_winter_0000, modfuture_events_winter_0000)

#Save as .csv
#write.csv(changeevents_spring_0000, "C:/Users/Documents/SPEI analysis/change files/changeevents_spring_0000_ex.csv")
#write.csv(changeevents_summer_0000, "C:/Users/Documents/SPEI analysis/change files/changeevents_summer_0000_ex.csv")
#write.csv(changeevents_autumn_0000, "C:/Users/Documents/SPEI analysis/change files/changeevents_autumn_0000_ex.csv")
#write.csv(changeevents_winter_0000, "C:/Users/Documents/SPEI analysis/change files/changeevents_winter_0000_ex.csv")


#Calculate change in drought months
changemonths_0000<-change(modpast_months_0000, modfuture_months_0000)

#Save as .csv
#write.csv(changemonths_0000, "C:/Users/Documents/SPEI analysis/change files/changemonths_0000.csv")


#Calculate change in number of drought months seasonally
changemonths_spring_0000<-change(modpast_months_spring_0000, modfuture_months_spring_0000)
changemonths_summer_0000<-change(modpast_months_summer_0000, modfuture_months_summer_0000)
changemonths_autumn_0000<-change(modpast_months_autumn_0000, modfuture_months_autumn_0000)
changemonths_winter_0000<-change(modpast_months_winter_0000, modfuture_months_winter_0000)

#Save as .csv
#write.csv(changemonths_spring_0000, "C:/Users/Documents/SPEI analysis/change files/changemonths_spring_0000.csv")
#write.csv(changemonths_summer_0000, "C:/Users/Documents/SPEI analysis/change files/changemonths_summer_0000.csv")
#write.csv(changemonths_autumn_0000, "C:/Users/Documents/SPEI analysis/change files/changemonths_autumn_0000.csv")
#write.csv(changemonths_winter_0000, "C:/Users/Documents/SPEI analysis/change files/changemonths_winter_0000.csv")


########################################## Model output 1113 #########################################

#Import data
p_mod_1113<-read.csv("prcp_1980_2040_mod_12km_1113.csv",
                     header=F)
t_mod_1113<-read.csv("tas_1980_2040_mod_12km_1113.csv",
                     header=F)

#Reformat
mod_1113<-reformat(p_mod_1113, t_mod_1113)

#Change coordinates
mod_1113 <- lat_calc(mod_1113)

#Calculate bias
base_1113 <- past(mod_1113, obs)
mod_1113 <- bias(base_1113, mod_1113)

#Split into datasets by location
mod_1113_split <- split(mod_1113, list(mod_1113$easting, mod_1113$northing))

#Calculate SPEI 
mod_1113_spei<-spei_calc(mod_1113_split)


#Calculate number of drought events
spei_y_1113<-years(mod_1113_spei)
modpast_events_1113<-events_mod(spei_y_1113[["past"]])
modpresent_events_1113<-events_mod(spei_y_1113[["present"]])
modfuture_events_1113<-events_mod(spei_y_1113[["future"]])

#Save as .csv
#write.csv(modpast_events_1113, "C:/Users/Documents/SPEI analysis/actual files/events_modpast_1113_ex.csv")
write.csv(modpresent_events_1113, "events_modpresent_1113_ex.csv")
#write.csv(modfuture_events_1113, "C:/Users/Documents/SPEI analysis/actual files/events_modfuture_1113_ex.csv")

#Calculate number of drought events by season
spei_ps_1113<-period_season(mod_1113_spei)
modpast_events_spring_1113<-events_season(spei_ps_1113[["past.spring"]])
modpast_events_summer_1113<-events_season(spei_ps_1113[["past.summer"]])
modpast_events_autumn_1113<-events_season(spei_ps_1113[["past.autumn"]])
modpast_events_winter_1113<-events_season(spei_ps_1113[["past.winter"]])

modpresent_events_spring_1113<-events_season(spei_ps_1113[["present.spring"]])
modpresent_events_summer_1113<-events_season(spei_ps_1113[["present.summer"]])
modpresent_events_autumn_1113<-events_season(spei_ps_1113[["present.autumn"]])
modpresent_events_winter_1113<-events_season(spei_ps_1113[["present.winter"]])

modfuture_events_spring_1113<-events_season(spei_ps_1113[["future.spring"]])
modfuture_events_summer_1113<-events_season(spei_ps_1113[["future.summer"]])
modfuture_events_autumn_1113<-events_season(spei_ps_1113[["future.autumn"]])
modfuture_events_winter_1113<-events_season(spei_ps_1113[["future.winter"]])

#Save as .csv
#write.csv(modpast_events_spring_1113, "C:/Users/Documents/SPEI analysis/actual files/events_modpast_spring_1113_ex.csv")
#write.csv(modpast_events_summer_1113, "C:/Users/Documents/SPEI analysis/actual files/events_modpast_summer_1113_ex.csv")
#write.csv(modpast_events_autumn_1113, "C:/Users/Documents/SPEI analysis/actual files/events_modpast_autumn_1113_ex.csv")
#write.csv(modpast_events_winter_1113, "C:/Users/Documents/SPEI analysis/actual files/events_modpast_winter_1113_ex.csv")

#write.csv(modpresent_events_spring_1113, "events_modpresent_spring_1113_ex.csv")
#write.csv(modpresent_events_summer_1113, "events_modpresent_summer_1113_ex.csv")
#write.csv(modpresent_events_autumn_1113, "events_modpresent_autumn_1113_ex.csv")
#write.csv(modpresent_events_winter_1113, "events_modpresent_winter_1113_ex.csv")

#write.csv(modfuture_events_spring_1113, "C:/Users/Documents/SPEI analysis/actual files/events_modfuture_spring_1113_ex.csv")
#write.csv(modfuture_events_summer_1113, "C:/Users/Documents/SPEI analysis/actual files/events_modfuture_summer_1113_ex.csv")
#write.csv(modfuture_events_autumn_1113, "C:/Users/Documents/SPEI analysis/actual files/events_modfuture_autumn_1113_ex.csv")
#write.csv(modfuture_events_winter_1113, "C:/Users/Documents/SPEI analysis/actual files/events_modfuture_winter_1113_ex.csv")


#Calculate number of drought months overall
modpast_months_1113<-months_mod(spei_y_1113[["past"]])
modpresent_months_1113<-months_mod(spei_y_1113[["present"]])
modfuture_months_1113<-months_mod(spei_y_1113[["future"]])

#Save as .csv
#write.csv(modpast_months_1113, "C:/Users/Documents/SPEI analysis/actual files/months_mod_actual_past_1113.csv")
#write.csv(modpresent_months_1113, "months_mod_actual_present_1113.csv")
#write.csv(modfuture_months_1113, "C:/Users/Documents/SPEI analysis/actual files/months_mod_actual_future_1113.csv")


#Calculate number of drought months
spei_s_1113<-seasons(mod_1113_spei)
modpast_months_spring_1113<-months_mod(spei_s_1113[["past"]][["spring"]])
modpast_months_summer_1113<-months_mod(spei_s_1113[["past"]][["summer"]])
modpast_months_autumn_1113<-months_mod(spei_s_1113[["past"]][["autumn"]])
modpast_months_winter_1113<-months_mod(spei_s_1113[["past"]][["winter"]])

modpresent_months_spring_1113<-months_mod(spei_s_1113[["present"]][["spring"]])
modpresent_months_summer_1113<-months_mod(spei_s_1113[["present"]][["summer"]])
modpresent_months_autumn_1113<-months_mod(spei_s_1113[["present"]][["autumn"]])
modpresent_months_winter_1113<-months_mod(spei_s_1113[["present"]][["winter"]])

modfuture_months_spring_1113<-months_mod(spei_s_1113[["future"]][["spring"]])
modfuture_months_summer_1113<-months_mod(spei_s_1113[["future"]][["summer"]])
modfuture_months_autumn_1113<-months_mod(spei_s_1113[["future"]][["autumn"]])
modfuture_months_winter_1113<-months_mod(spei_s_1113[["future"]][["winter"]])

#Save as .csv
#write.csv(modpast_months_spring_1113, "C:/Users/Documents/SPEI analysis/actual files/months_modpast_spring_1113.csv")
#write.csv(modpast_months_summer_1113, "C:/Users/Documents/SPEI analysis/actual files/months_modpast_summer_1113.csv")
#write.csv(modpast_months_autumn_1113, "C:/Users/Documents/SPEI analysis/actual files/months_modpast_autumn_1113.csv")
#write.csv(modpast_months_winter_1113, "C:/Users/Documents/SPEI analysis/actual files/months_modpast_winter_1113.csv")

#write.csv(modpresent_months_spring_1113, "months_modpresent_spring_1113.csv")
#write.csv(modpresent_months_summer_1113, "months_modpresent_summer_1113.csv")
#write.csv(modpresent_months_autumn_1113, "months_modpresent_autumn_1113.csv")
#write.csv(modpresent_months_winter_1113, "months_modpresent_winter_1113.csv")

#write.csv(modfuture_months_spring_1113, "C:/Users/Documents/SPEI analysis/actual files/months_modfuture_spring_1113.csv")
#write.csv(modfuture_months_summer_1113, "C:/Users/Documents/SPEI analysis/actual files/months_modfuture_summer_1113.csv")
#write.csv(modfuture_months_autumn_1113, "C:/Users/Documents/SPEI analysis/actual files/months_modfuture_autumn_1113.csv")
#write.csv(modfuture_months_winter_1113, "C:/Users/Documents/SPEI analysis/actual files/months_modfuture_winter_1113.csv")


#Calculate change in number of drought events
changeevents_1113<-change(modpast_events_1113, modfuture_events_1113)

#Save as .csv
#write.csv(changeevents_1113, "C:/Users/Documents/SPEI analysis/change files/changeevents_1113_ex.csv")

#Calculate change in number of drought events seasonally
changeevents_spring_1113<-change(modpast_events_spring_1113, modfuture_events_spring_1113)
changeevents_summer_1113<-change(modpast_events_summer_1113, modfuture_events_summer_1113)
changeevents_autumn_1113<-change(modpast_events_autumn_1113, modfuture_events_autumn_1113)
changeevents_winter_1113<-change(modpast_events_winter_1113, modfuture_events_winter_1113)

#Save as .csv
#write.csv(changeevents_spring_1113, "C:/Users/Documents/SPEI analysis/change files/changeevents_spring_1113_ex.csv")
#write.csv(changeevents_summer_1113, "C:/Users/Documents/SPEI analysis/change files/changeevents_summer_1113_ex.csv")
#write.csv(changeevents_autumn_1113, "C:/Users/Documents/SPEI analysis/change files/changeevents_autumn_1113_ex.csv")
#write.csv(changeevents_winter_1113, "C:/Users/Documents/SPEI analysis/change files/changeevents_winter_1113_ex.csv")


#Calculate change in drought months
changemonths_1113<-change(modpast_months_1113, modfuture_months_1113)

#Save as .csv
#write.csv(changemonths_1113, "C:/Users/Documents/SPEI analysis/change files/changemonths_1113.csv")


#Calculate change in number of drought months seasonally
changemonths_spring_1113<-change(modpast_months_spring_1113, modfuture_months_spring_1113)
changemonths_summer_1113<-change(modpast_months_summer_1113, modfuture_months_summer_1113)
changemonths_autumn_1113<-change(modpast_months_autumn_1113, modfuture_months_autumn_1113)
changemonths_winter_1113<-change(modpast_months_winter_1113, modfuture_months_winter_1113)

#Save as .csv
#write.csv(changemonths_spring_1113, "C:/Users/Documents/SPEI analysis/change files/changemonths_spring_1113.csv")
#write.csv(changemonths_summer_1113, "C:/Users/Documents/SPEI analysis/change files/changemonths_summer_1113.csv")
#write.csv(changemonths_autumn_1113, "C:/Users/Documents/SPEI analysis/change files/changemonths_autumn_1113.csv")
#write.csv(changemonths_winter_1113, "C:/Users/Documents/SPEI analysis/change files/changemonths_winter_1113.csv")


########################################## Model output 1554 #########################################

#Import data
p_mod_1554<-read.csv("prcp_1980_2040_mod_12km_1554.csv",
                     header=F)
t_mod_1554<-read.csv("tas_1980_2040_mod_12km_1554.csv",
                     header=F)

#Reformat
mod_1554<-reformat(p_mod_1554, t_mod_1554)

#Change coordinates
mod_1554 <- lat_calc(mod_1554)

#Calculate bias
base_1554 <- past(mod_1554, obs)
mod_1554 <- bias(base_1554, mod_1554)

#Split into datasets by location
mod_1554_split <- split(mod_1554, list(mod_1554$easting, mod_1554$northing))

#Calculate SPEI 
mod_1554_spei<-spei_calc(mod_1554_split)


#Calculate number of drought events
spei_y_1554<-years(mod_1554_spei)
modpast_events_1554<-events_mod(spei_y_1554[["past"]])
modpresent_events_1554<-events_mod(spei_y_1554[["present"]])
modfuture_events_1554<-events_mod(spei_y_1554[["future"]])

#Save as .csv
#write.csv(modpast_events_1554, "C:/Users/Documents/SPEI analysis/actual files/events_modpast_1554_ex.csv")
write.csv(modpresent_events_1554, "events_modpresent_1554_ex.csv")
#write.csv(modfuture_events_1554, "C:/Users/Documents/SPEI analysis/actual files/events_modfuture_1554_ex.csv")

#Calculate number of drought events by season
spei_ps_1554<-period_season(mod_1554_spei)
modpast_events_spring_1554<-events_season(spei_ps_1554[["past.spring"]])
modpast_events_summer_1554<-events_season(spei_ps_1554[["past.summer"]])
modpast_events_autumn_1554<-events_season(spei_ps_1554[["past.autumn"]])
modpast_events_winter_1554<-events_season(spei_ps_1554[["past.winter"]])

modpresent_events_spring_1554<-events_season(spei_ps_1554[["present.spring"]])
modpresent_events_summer_1554<-events_season(spei_ps_1554[["present.summer"]])
modpresent_events_autumn_1554<-events_season(spei_ps_1554[["present.autumn"]])
modpresent_events_winter_1554<-events_season(spei_ps_1554[["present.winter"]])

modfuture_events_spring_1554<-events_season(spei_ps_1554[["future.spring"]])
modfuture_events_summer_1554<-events_season(spei_ps_1554[["future.summer"]])
modfuture_events_autumn_1554<-events_season(spei_ps_1554[["future.autumn"]])
modfuture_events_winter_1554<-events_season(spei_ps_1554[["future.winter"]])

#Save as .csv
#write.csv(modpast_events_spring_1554, "C:/Users/Documents/SPEI analysis/actual files/events_modpast_spring_1554_ex.csv")
#write.csv(modpast_events_summer_1554, "C:/Users/Documents/SPEI analysis/actual files/events_modpast_summer_1554_ex.csv")
#write.csv(modpast_events_autumn_1554, "C:/Users/Documents/SPEI analysis/actual files/events_modpast_autumn_1554_ex.csv")
#write.csv(modpast_events_winter_1554, "C:/Users/Documents/SPEI analysis/actual files/events_modpast_winter_1554_ex.csv")

#write.csv(modpresent_events_spring_1554, "events_modpresent_spring_1554_ex.csv")
#write.csv(modpresent_events_summer_1554, "events_modpresent_summer_1554_ex.csv")
#write.csv(modpresent_events_autumn_1554, "events_modpresent_autumn_1554_ex.csv")
#write.csv(modpresent_events_winter_1554, "events_modpresent_winter_1554_ex.csv")

#write.csv(modfuture_events_spring_1554, "C:/Users/Documents/SPEI analysis/actual files/events_modfuture_spring_1554_ex.csv")
#write.csv(modfuture_events_summer_1554, "C:/Users/Documents/SPEI analysis/actual files/events_modfuture_summer_1554_ex.csv")
#write.csv(modfuture_events_autumn_1554, "C:/Users/Documents/SPEI analysis/actual files/events_modfuture_autumn_1554_ex.csv")
#write.csv(modfuture_events_winter_1554, "C:/Users/Documents/SPEI analysis/actual files/events_modfuture_winter_1554_ex.csv")


#Calculate number of drought months overall
modpast_months_1554<-months_mod(spei_y_1554[["past"]])
modpresent_months_1554<-months_mod(spei_y_1554[["present"]])
modfuture_months_1554<-months_mod(spei_y_1554[["future"]])

#Save as .csv
#write.csv(modpast_months_1554, "C:/Users/Documents/SPEI analysis/actual files/months_mod_actual_past_1554.csv")
#write.csv(modpresent_months_1554, "months_mod_actual_present_1554.csv")
#write.csv(modfuture_months_1554, "C:/Users/Documents/SPEI analysis/actual files/months_mod_actual_future_1554.csv")


#Calculate number of drought months
spei_s_1554<-seasons(mod_1554_spei)
modpast_months_spring_1554<-months_mod(spei_s_1554[["past"]][["spring"]])
modpast_months_summer_1554<-months_mod(spei_s_1554[["past"]][["summer"]])
modpast_months_autumn_1554<-months_mod(spei_s_1554[["past"]][["autumn"]])
modpast_months_winter_1554<-months_mod(spei_s_1554[["past"]][["winter"]])

modpresent_months_spring_1554<-months_mod(spei_s_1554[["present"]][["spring"]])
modpresent_months_summer_1554<-months_mod(spei_s_1554[["present"]][["summer"]])
modpresent_months_autumn_1554<-months_mod(spei_s_1554[["present"]][["autumn"]])
modpresent_months_winter_1554<-months_mod(spei_s_1554[["present"]][["winter"]])

modfuture_months_spring_1554<-months_mod(spei_s_1554[["future"]][["spring"]])
modfuture_months_summer_1554<-months_mod(spei_s_1554[["future"]][["summer"]])
modfuture_months_autumn_1554<-months_mod(spei_s_1554[["future"]][["autumn"]])
modfuture_months_winter_1554<-months_mod(spei_s_1554[["future"]][["winter"]])

#Save as .csv
#write.csv(modpast_months_spring_1554, "C:/Users/Documents/SPEI analysis/actual files/months_modpast_spring_1554.csv")
#write.csv(modpast_months_summer_1554, "C:/Users/Documents/SPEI analysis/actual files/months_modpast_summer_1554.csv")
#write.csv(modpast_months_autumn_1554, "C:/Users/Documents/SPEI analysis/actual files/months_modpast_autumn_1554.csv")
#write.csv(modpast_months_winter_1554, "C:/Users/Documents/SPEI analysis/actual files/months_modpast_winter_1554.csv")

#write.csv(modpresent_months_spring_1554, "months_modpresent_spring_1554.csv")
#write.csv(modpresent_months_summer_1554, "months_modpresent_summer_1554.csv")
#write.csv(modpresent_months_autumn_1554, "months_modpresent_autumn_1554.csv")
#write.csv(modpresent_months_winter_1554, "months_modpresent_winter_1554.csv")

#write.csv(modfuture_months_spring_1554, "C:/Users/Documents/SPEI analysis/actual files/months_modfuture_spring_1554.csv")
#write.csv(modfuture_months_summer_1554, "C:/Users/Documents/SPEI analysis/actual files/months_modfuture_summer_1554.csv")
#write.csv(modfuture_months_autumn_1554, "C:/Users/Documents/SPEI analysis/actual files/months_modfuture_autumn_1554.csv")
#write.csv(modfuture_months_winter_1554, "C:/Users/Documents/SPEI analysis/actual files/months_modfuture_winter_1554.csv")


#Calculate change in number of drought events
changeevents_1554<-change(modpast_events_1554, modfuture_events_1554)

#Save as .csv
#write.csv(changeevents_1554, "C:/Users/Documents/SPEI analysis/change files/changeevents_1554_ex.csv")

#Calculate change in number of drought events seasonally
changeevents_spring_1554<-change(modpast_events_spring_1554, modfuture_events_spring_1554)
changeevents_summer_1554<-change(modpast_events_summer_1554, modfuture_events_summer_1554)
changeevents_autumn_1554<-change(modpast_events_autumn_1554, modfuture_events_autumn_1554)
changeevents_winter_1554<-change(modpast_events_winter_1554, modfuture_events_winter_1554)

#Save as .csv
#write.csv(changeevents_spring_1554, "C:/Users/Documents/SPEI analysis/change files/changeevents_spring_1554_ex.csv")
#write.csv(changeevents_summer_1554, "C:/Users/Documents/SPEI analysis/change files/changeevents_summer_1554_ex.csv")
#write.csv(changeevents_autumn_1554, "C:/Users/Documents/SPEI analysis/change files/changeevents_autumn_1554_ex.csv")
#write.csv(changeevents_winter_1554, "C:/Users/Documents/SPEI analysis/change files/changeevents_winter_1554_ex.csv")


#Calculate change in drought months
changemonths_1554<-change(modpast_months_1554, modfuture_months_1554)

#Save as .csv
#write.csv(changemonths_1554, "C:/Users/Documents/SPEI analysis/change files/changemonths_1554.csv")


#Calculate change in number of drought months seasonally
changemonths_spring_1554<-change(modpast_months_spring_1554, modfuture_months_spring_1554)
changemonths_summer_1554<-change(modpast_months_summer_1554, modfuture_months_summer_1554)
changemonths_autumn_1554<-change(modpast_months_autumn_1554, modfuture_months_autumn_1554)
changemonths_winter_1554<-change(modpast_months_winter_1554, modfuture_months_winter_1554)

#Save as .csv
#write.csv(changemonths_spring_1554, "C:/Users/Documents/SPEI analysis/change files/changemonths_spring_1554.csv")
#write.csv(changemonths_summer_1554, "C:/Users/Documents/SPEI analysis/change files/changemonths_summer_1554.csv")
#write.csv(changemonths_autumn_1554, "C:/Users/Documents/SPEI analysis/change files/changemonths_autumn_1554.csv")
#write.csv(changemonths_winter_1554, "C:/Users/Documents/SPEI analysis/change files/changemonths_winter_1554.csv")


########################################## Model output 1649 #########################################

#Import data
p_mod_1649<-read.csv("prcp_1980_2040_mod_12km_1649.csv",
                     header=F)
t_mod_1649<-read.csv("tas_1980_2040_mod_12km_1649.csv",
                     header=F)

#Reformat
mod_1649<-reformat(p_mod_1649, t_mod_1649)

#Change coordinates
mod_1649 <- lat_calc(mod_1649)

#Calculate bias
base_1649 <- past(mod_1649, obs)
mod_1649 <- bias(base_1649, mod_1649)

#Split into datasets by location
mod_1649_split <- split(mod_1649, list(mod_1649$easting, mod_1649$northing))

#Calculate SPEI 
mod_1649_spei<-spei_calc(mod_1649_split)


#Calculate number of drought events
spei_y_1649<-years(mod_1649_spei)
modpast_events_1649<-events_mod(spei_y_1649[["past"]])
modpresent_events_1649<-events_mod(spei_y_1649[["present"]])
modfuture_events_1649<-events_mod(spei_y_1649[["future"]])

#Save as .csv
#write.csv(modpast_events_1649, "C:/Users/Documents/SPEI analysis/actual files/events_modpast_1649_ex.csv")
write.csv(modpresent_events_1649, "events_modpresent_1649_ex.csv")
#write.csv(modfuture_events_1649, "C:/Users/Documents/SPEI analysis/actual files/events_modfuture_1649_ex.csv")

#Calculate number of drought events by season
spei_ps_1649<-period_season(mod_1649_spei)
modpast_events_spring_1649<-events_season(spei_ps_1649[["past.spring"]])
modpast_events_summer_1649<-events_season(spei_ps_1649[["past.summer"]])
modpast_events_autumn_1649<-events_season(spei_ps_1649[["past.autumn"]])
modpast_events_winter_1649<-events_season(spei_ps_1649[["past.winter"]])

modpresent_events_spring_1649<-events_season(spei_ps_1649[["present.spring"]])
modpresent_events_summer_1649<-events_season(spei_ps_1649[["present.summer"]])
modpresent_events_autumn_1649<-events_season(spei_ps_1649[["present.autumn"]])
modpresent_events_winter_1649<-events_season(spei_ps_1649[["present.winter"]])

modfuture_events_spring_1649<-events_season(spei_ps_1649[["future.spring"]])
modfuture_events_summer_1649<-events_season(spei_ps_1649[["future.summer"]])
modfuture_events_autumn_1649<-events_season(spei_ps_1649[["future.autumn"]])
modfuture_events_winter_1649<-events_season(spei_ps_1649[["future.winter"]])

#Save as .csv
#write.csv(modpast_events_spring_1649, "C:/Users/Documents/SPEI analysis/actual files/events_modpast_spring_1649_ex.csv")
#write.csv(modpast_events_summer_1649, "C:/Users/Documents/SPEI analysis/actual files/events_modpast_summer_1649_ex.csv")
#write.csv(modpast_events_autumn_1649, "C:/Users/Documents/SPEI analysis/actual files/events_modpast_autumn_1649_ex.csv")
#write.csv(modpast_events_winter_1649, "C:/Users/Documents/SPEI analysis/actual files/events_modpast_winter_1649_ex.csv")

#write.csv(modpresent_events_spring_1649, "events_modpresent_spring_1649_ex.csv")
#write.csv(modpresent_events_summer_1649, "events_modpresent_summer_1649_ex.csv")
#write.csv(modpresent_events_autumn_1649, "events_modpresent_autumn_1649_ex.csv")
#write.csv(modpresent_events_winter_1649, "events_modpresent_winter_1649_ex.csv")

#write.csv(modfuture_events_spring_1649, "C:/Users/Documents/SPEI analysis/actual files/events_modfuture_spring_1649_ex.csv")
#write.csv(modfuture_events_summer_1649, "C:/Users/Documents/SPEI analysis/actual files/events_modfuture_summer_1649_ex.csv")
#write.csv(modfuture_events_autumn_1649, "C:/Users/Documents/SPEI analysis/actual files/events_modfuture_autumn_1649_ex.csv")
#write.csv(modfuture_events_winter_1649, "C:/Users/Documents/SPEI analysis/actual files/events_modfuture_winter_1649_ex.csv")


#Calculate number of drought months overall
modpast_months_1649<-months_mod(spei_y_1649[["past"]])
modpresent_months_1649<-months_mod(spei_y_1649[["present"]])
modfuture_months_1649<-months_mod(spei_y_1649[["future"]])

#Save as .csv
#write.csv(modpast_months_1649, "C:/Users/Documents/SPEI analysis/actual files/months_mod_actual_past_1649.csv")
#write.csv(modpresent_months_1649, "months_mod_actual_present_1649.csv")
#write.csv(modfuture_months_1649, "C:/Users/Documents/SPEI analysis/actual files/months_mod_actual_future_1649.csv")


#Calculate number of drought months
spei_s_1649<-seasons(mod_1649_spei)
modpast_months_spring_1649<-months_mod(spei_s_1649[["past"]][["spring"]])
modpast_months_summer_1649<-months_mod(spei_s_1649[["past"]][["summer"]])
modpast_months_autumn_1649<-months_mod(spei_s_1649[["past"]][["autumn"]])
modpast_months_winter_1649<-months_mod(spei_s_1649[["past"]][["winter"]])

modpresent_months_spring_1649<-months_mod(spei_s_1649[["present"]][["spring"]])
modpresent_months_summer_1649<-months_mod(spei_s_1649[["present"]][["summer"]])
modpresent_months_autumn_1649<-months_mod(spei_s_1649[["present"]][["autumn"]])
modpresent_months_winter_1649<-months_mod(spei_s_1649[["present"]][["winter"]])

modfuture_months_spring_1649<-months_mod(spei_s_1649[["future"]][["spring"]])
modfuture_months_summer_1649<-months_mod(spei_s_1649[["future"]][["summer"]])
modfuture_months_autumn_1649<-months_mod(spei_s_1649[["future"]][["autumn"]])
modfuture_months_winter_1649<-months_mod(spei_s_1649[["future"]][["winter"]])

#Save as .csv
#write.csv(modpast_months_spring_1649, "C:/Users/Documents/SPEI analysis/actual files/months_modpast_spring_1649.csv")
#write.csv(modpast_months_summer_1649, "C:/Users/Documents/SPEI analysis/actual files/months_modpast_summer_1649.csv")
#write.csv(modpast_months_autumn_1649, "C:/Users/Documents/SPEI analysis/actual files/months_modpast_autumn_1649.csv")
#write.csv(modpast_months_winter_1649, "C:/Users/Documents/SPEI analysis/actual files/months_modpast_winter_1649.csv")

#write.csv(modpresent_months_spring_1649, "months_modpresent_spring_1649.csv")
#write.csv(modpresent_months_summer_1649, "months_modpresent_summer_1649.csv")
#write.csv(modpresent_months_autumn_1649, "months_modpresent_autumn_1649.csv")
#write.csv(modpresent_months_winter_1649, "months_modpresent_winter_1649.csv")

#write.csv(modfuture_months_spring_1649, "C:/Users/Documents/SPEI analysis/actual files/months_modfuture_spring_1649.csv")
#write.csv(modfuture_months_summer_1649, "C:/Users/Documents/SPEI analysis/actual files/months_modfuture_summer_1649.csv")
#write.csv(modfuture_months_autumn_1649, "C:/Users/Documents/SPEI analysis/actual files/months_modfuture_autumn_1649.csv")
#write.csv(modfuture_months_winter_1649, "C:/Users/Documents/SPEI analysis/actual files/months_modfuture_winter_1649.csv")


#Calculate change in number of drought events
changeevents_1649<-change(modpast_events_1649, modfuture_events_1649)

#Save as .csv
#write.csv(changeevents_1649, "C:/Users/Documents/SPEI analysis/change files/changeevents_1649_ex.csv")

#Calculate change in number of drought events seasonally
changeevents_spring_1649<-change(modpast_events_spring_1649, modfuture_events_spring_1649)
changeevents_summer_1649<-change(modpast_events_summer_1649, modfuture_events_summer_1649)
changeevents_autumn_1649<-change(modpast_events_autumn_1649, modfuture_events_autumn_1649)
changeevents_winter_1649<-change(modpast_events_winter_1649, modfuture_events_winter_1649)

#Save as .csv
#write.csv(changeevents_spring_1649, "C:/Users/Documents/SPEI analysis/change files/changeevents_spring_1649_ex.csv")
#write.csv(changeevents_summer_1649, "C:/Users/Documents/SPEI analysis/change files/changeevents_summer_1649_ex.csv")
#write.csv(changeevents_autumn_1649, "C:/Users/Documents/SPEI analysis/change files/changeevents_autumn_1649_ex.csv")
#write.csv(changeevents_winter_1649, "C:/Users/Documents/SPEI analysis/change files/changeevents_winter_1649_ex.csv")


#Calculate change in drought months
changemonths_1649<-change(modpast_months_1649, modfuture_months_1649)

#Save as .csv
#write.csv(changemonths_1649, "C:/Users/Documents/SPEI analysis/change files/changemonths_1649.csv")


#Calculate change in number of drought months seasonally
changemonths_spring_1649<-change(modpast_months_spring_1649, modfuture_months_spring_1649)
changemonths_summer_1649<-change(modpast_months_summer_1649, modfuture_months_summer_1649)
changemonths_autumn_1649<-change(modpast_months_autumn_1649, modfuture_months_autumn_1649)
changemonths_winter_1649<-change(modpast_months_winter_1649, modfuture_months_winter_1649)

#Save as .csv
#write.csv(changemonths_spring_1649, "C:/Users/Documents/SPEI analysis/change files/changemonths_spring_1649.csv")
#write.csv(changemonths_summer_1649, "C:/Users/Documents/SPEI analysis/change files/changemonths_summer_1649.csv")
#write.csv(changemonths_autumn_1649, "C:/Users/Documents/SPEI analysis/change files/changemonths_autumn_1649.csv")
#write.csv(changemonths_winter_1649, "C:/Users/Documents/SPEI analysis/change files/changemonths_winter_1649.csv")


########################################## Model output 1843 #########################################

#Import data
p_mod_1843<-read.csv("prcp_1980_2040_mod_12km_1843.csv",
                     header=F)
t_mod_1843<-read.csv("tas_1980_2040_mod_12km_1843.csv",
                     header=F)

#Reformat
mod_1843<-reformat(p_mod_1843, t_mod_1843)

#Change coordinates
mod_1843 <- lat_calc(mod_1843)

#Calculate bias
base_1843 <- past(mod_1843, obs)
mod_1843 <- bias(base_1843, mod_1843)

#Split into datasets by location
mod_1843_split <- split(mod_1843, list(mod_1843$easting, mod_1843$northing))

#Calculate SPEI 
mod_1843_spei<-spei_calc(mod_1843_split)


#Calculate number of drought events
spei_y_1843<-years(mod_1843_spei)
modpast_events_1843<-events_mod(spei_y_1843[["past"]])
modpresent_events_1843<-events_mod(spei_y_1843[["present"]])
modfuture_events_1843<-events_mod(spei_y_1843[["future"]])

#Save as .csv
#write.csv(modpast_events_1843, "C:/Users/Documents/SPEI analysis/actual files/events_modpast_1843_ex.csv")
write.csv(modpresent_events_1843, "events_modpresent_1843_ex.csv")
#write.csv(modfuture_events_1843, "C:/Users/Documents/SPEI analysis/actual files/events_modfuture_1843_ex.csv")

#Calculate number of drought events by season
spei_ps_1843<-period_season(mod_1843_spei)
modpast_events_spring_1843<-events_season(spei_ps_1843[["past.spring"]])
modpast_events_summer_1843<-events_season(spei_ps_1843[["past.summer"]])
modpast_events_autumn_1843<-events_season(spei_ps_1843[["past.autumn"]])
modpast_events_winter_1843<-events_season(spei_ps_1843[["past.winter"]])

modpresent_events_spring_1843<-events_season(spei_ps_1843[["present.spring"]])
modpresent_events_summer_1843<-events_season(spei_ps_1843[["present.summer"]])
modpresent_events_autumn_1843<-events_season(spei_ps_1843[["present.autumn"]])
modpresent_events_winter_1843<-events_season(spei_ps_1843[["present.winter"]])

modfuture_events_spring_1843<-events_season(spei_ps_1843[["future.spring"]])
modfuture_events_summer_1843<-events_season(spei_ps_1843[["future.summer"]])
modfuture_events_autumn_1843<-events_season(spei_ps_1843[["future.autumn"]])
modfuture_events_winter_1843<-events_season(spei_ps_1843[["future.winter"]])

#Save as .csv
#write.csv(modpast_events_spring_1843, "C:/Users/Documents/SPEI analysis/actual files/events_modpast_spring_1843_ex.csv")
#write.csv(modpast_events_summer_1843, "C:/Users/Documents/SPEI analysis/actual files/events_modpast_summer_1843_ex.csv")
#write.csv(modpast_events_autumn_1843, "C:/Users/Documents/SPEI analysis/actual files/events_modpast_autumn_1843_ex.csv")
#write.csv(modpast_events_winter_1843, "C:/Users/Documents/SPEI analysis/actual files/events_modpast_winter_1843_ex.csv")

#write.csv(modpresent_events_spring_1843, "events_modpresent_spring_1843_ex.csv")
#write.csv(modpresent_events_summer_1843, "events_modpresent_summer_1843_ex.csv")
#write.csv(modpresent_events_autumn_1843, "events_modpresent_autumn_1843_ex.csv")
#write.csv(modpresent_events_winter_1843, "events_modpresent_winter_1843_ex.csv")

#write.csv(modfuture_events_spring_1843, "C:/Users/Documents/SPEI analysis/actual files/events_modfuture_spring_1843_ex.csv")
#write.csv(modfuture_events_summer_1843, "C:/Users/Documents/SPEI analysis/actual files/events_modfuture_summer_1843_ex.csv")
#write.csv(modfuture_events_autumn_1843, "C:/Users/Documents/SPEI analysis/actual files/events_modfuture_autumn_1843_ex.csv")
#write.csv(modfuture_events_winter_1843, "C:/Users/Documents/SPEI analysis/actual files/events_modfuture_winter_1843_ex.csv")


#Calculate number of drought months overall
modpast_months_1843<-months_mod(spei_y_1843[["past"]])
modpresent_months_1843<-months_mod(spei_y_1843[["present"]])
modfuture_months_1843<-months_mod(spei_y_1843[["future"]])

#Save as .csv
#write.csv(modpast_months_1843, "C:/Users/Documents/SPEI analysis/actual files/months_mod_actual_past_1843.csv")
#write.csv(modpresent_months_1843, "months_mod_actual_present_1843.csv")
#write.csv(modfuture_months_1843, "C:/Users/Documents/SPEI analysis/actual files/months_mod_actual_future_1843.csv")


#Calculate number of drought months
spei_s_1843<-seasons(mod_1843_spei)
modpast_months_spring_1843<-months_mod(spei_s_1843[["past"]][["spring"]])
modpast_months_summer_1843<-months_mod(spei_s_1843[["past"]][["summer"]])
modpast_months_autumn_1843<-months_mod(spei_s_1843[["past"]][["autumn"]])
modpast_months_winter_1843<-months_mod(spei_s_1843[["past"]][["winter"]])

modpresent_months_spring_1843<-months_mod(spei_s_1843[["present"]][["spring"]])
modpresent_months_summer_1843<-months_mod(spei_s_1843[["present"]][["summer"]])
modpresent_months_autumn_1843<-months_mod(spei_s_1843[["present"]][["autumn"]])
modpresent_months_winter_1843<-months_mod(spei_s_1843[["present"]][["winter"]])

modfuture_months_spring_1843<-months_mod(spei_s_1843[["future"]][["spring"]])
modfuture_months_summer_1843<-months_mod(spei_s_1843[["future"]][["summer"]])
modfuture_months_autumn_1843<-months_mod(spei_s_1843[["future"]][["autumn"]])
modfuture_months_winter_1843<-months_mod(spei_s_1843[["future"]][["winter"]])

#Save as .csv
#write.csv(modpast_months_spring_1843, "C:/Users/Documents/SPEI analysis/actual files/months_modpast_spring_1843.csv")
#write.csv(modpast_months_summer_1843, "C:/Users/Documents/SPEI analysis/actual files/months_modpast_summer_1843.csv")
#write.csv(modpast_months_autumn_1843, "C:/Users/Documents/SPEI analysis/actual files/months_modpast_autumn_1843.csv")
#write.csv(modpast_months_winter_1843, "C:/Users/Documents/SPEI analysis/actual files/months_modpast_winter_1843.csv")

#write.csv(modpresent_months_spring_1843, "months_modpresent_spring_1843.csv")
#write.csv(modpresent_months_summer_1843, "months_modpresent_summer_1843.csv")
#write.csv(modpresent_months_autumn_1843, "months_modpresent_autumn_1843.csv")
#write.csv(modpresent_months_winter_1843, "months_modpresent_winter_1843.csv")

#write.csv(modfuture_months_spring_1843, "C:/Users/Documents/SPEI analysis/actual files/months_modfuture_spring_1843.csv")
#write.csv(modfuture_months_summer_1843, "C:/Users/Documents/SPEI analysis/actual files/months_modfuture_summer_1843.csv")
#write.csv(modfuture_months_autumn_1843, "C:/Users/Documents/SPEI analysis/actual files/months_modfuture_autumn_1843.csv")
#write.csv(modfuture_months_winter_1843, "C:/Users/Documents/SPEI analysis/actual files/months_modfuture_winter_1843.csv")


#Calculate change in number of drought events
changeevents_1843<-change(modpast_events_1843, modfuture_events_1843)

#Save as .csv
#write.csv(changeevents_1843, "C:/Users/Documents/SPEI analysis/change files/changeevents_1843_ex.csv")

#Calculate change in number of drought events seasonally
changeevents_spring_1843<-change(modpast_events_spring_1843, modfuture_events_spring_1843)
changeevents_summer_1843<-change(modpast_events_summer_1843, modfuture_events_summer_1843)
changeevents_autumn_1843<-change(modpast_events_autumn_1843, modfuture_events_autumn_1843)
changeevents_winter_1843<-change(modpast_events_winter_1843, modfuture_events_winter_1843)

#Save as .csv
#write.csv(changeevents_spring_1843, "C:/Users/Documents/SPEI analysis/change files/changeevents_spring_1843_ex.csv")
#write.csv(changeevents_summer_1843, "C:/Users/Documents/SPEI analysis/change files/changeevents_summer_1843_ex.csv")
#write.csv(changeevents_autumn_1843, "C:/Users/Documents/SPEI analysis/change files/changeevents_autumn_1843_ex.csv")
#write.csv(changeevents_winter_1843, "C:/Users/Documents/SPEI analysis/change files/changeevents_winter_1843_ex.csv")


#Calculate change in drought months
changemonths_1843<-change(modpast_months_1843, modfuture_months_1843)

#Save as .csv
#write.csv(changemonths_1843, "C:/Users/Documents/SPEI analysis/change files/changemonths_1843.csv")


#Calculate change in number of drought months seasonally
changemonths_spring_1843<-change(modpast_months_spring_1843, modfuture_months_spring_1843)
changemonths_summer_1843<-change(modpast_months_summer_1843, modfuture_months_summer_1843)
changemonths_autumn_1843<-change(modpast_months_autumn_1843, modfuture_months_autumn_1843)
changemonths_winter_1843<-change(modpast_months_winter_1843, modfuture_months_winter_1843)

#Save as .csv
#write.csv(changemonths_spring_1843, "C:/Users/Documents/SPEI analysis/change files/changemonths_spring_1843.csv")
#write.csv(changemonths_summer_1843, "C:/Users/Documents/SPEI analysis/change files/changemonths_summer_1843.csv")
#write.csv(changemonths_autumn_1843, "C:/Users/Documents/SPEI analysis/change files/changemonths_autumn_1843.csv")
#write.csv(changemonths_winter_1843, "C:/Users/Documents/SPEI analysis/change files/changemonths_winter_1843.csv")


########################################## Model output 1935 #########################################

#Import data
p_mod_1935<-read.csv("prcp_1980_2040_mod_12km_1935.csv",
                     header=F)
t_mod_1935<-read.csv("tas_1980_2040_mod_12km_1935.csv",
                     header=F)

#Reformat
mod_1935<-reformat(p_mod_1935, t_mod_1935)

#Change coordinates
mod_1935 <- lat_calc(mod_1935)

#Calculate bias
base_1935 <- past(mod_1935, obs)
mod_1935 <- bias(base_1935, mod_1935)

#Split into datasets by location
mod_1935_split <- split(mod_1935, list(mod_1935$easting, mod_1935$northing))

#Calculate SPEI 
mod_1935_spei<-spei_calc(mod_1935_split)


#Calculate number of drought events
spei_y_1935<-years(mod_1935_spei)
modpast_events_1935<-events_mod(spei_y_1935[["past"]])
modpresent_events_1935<-events_mod(spei_y_1935[["present"]])
modfuture_events_1935<-events_mod(spei_y_1935[["future"]])

#Save as .csv
#write.csv(modpast_events_1935, "C:/Users/Documents/SPEI analysis/actual files/events_modpast_1935_ex.csv")
write.csv(modpresent_events_1935, "events_modpresent_1935_ex.csv")
#write.csv(modfuture_events_1935, "C:/Users/Documents/SPEI analysis/actual files/events_modfuture_1935_ex.csv")

#Calculate number of drought events by season
spei_ps_1935<-period_season(mod_1935_spei)
modpast_events_spring_1935<-events_season(spei_ps_1935[["past.spring"]])
modpast_events_summer_1935<-events_season(spei_ps_1935[["past.summer"]])
modpast_events_autumn_1935<-events_season(spei_ps_1935[["past.autumn"]])
modpast_events_winter_1935<-events_season(spei_ps_1935[["past.winter"]])

modpresent_events_spring_1935<-events_season(spei_ps_1935[["present.spring"]])
modpresent_events_summer_1935<-events_season(spei_ps_1935[["present.summer"]])
modpresent_events_autumn_1935<-events_season(spei_ps_1935[["present.autumn"]])
modpresent_events_winter_1935<-events_season(spei_ps_1935[["present.winter"]])

modfuture_events_spring_1935<-events_season(spei_ps_1935[["future.spring"]])
modfuture_events_summer_1935<-events_season(spei_ps_1935[["future.summer"]])
modfuture_events_autumn_1935<-events_season(spei_ps_1935[["future.autumn"]])
modfuture_events_winter_1935<-events_season(spei_ps_1935[["future.winter"]])

#Save as .csv
#write.csv(modpast_events_spring_1935, "C:/Users/Documents/SPEI analysis/actual files/events_modpast_spring_1935_ex.csv")
#write.csv(modpast_events_summer_1935, "C:/Users/Documents/SPEI analysis/actual files/events_modpast_summer_1935_ex.csv")
#write.csv(modpast_events_autumn_1935, "C:/Users/Documents/SPEI analysis/actual files/events_modpast_autumn_1935_ex.csv")
#write.csv(modpast_events_winter_1935, "C:/Users/Documents/SPEI analysis/actual files/events_modpast_winter_1935_ex.csv")

#write.csv(modpresent_events_spring_1935, "events_modpresent_spring_1935_ex.csv")
#write.csv(modpresent_events_summer_1935, "events_modpresent_summer_1935_ex.csv")
#write.csv(modpresent_events_autumn_1935, "events_modpresent_autumn_1935_ex.csv")
#write.csv(modpresent_events_winter_1935, "events_modpresent_winter_1935_ex.csv")

#write.csv(modfuture_events_spring_1935, "C:/Users/Documents/SPEI analysis/actual files/events_modfuture_spring_1935_ex.csv")
#write.csv(modfuture_events_summer_1935, "C:/Users/Documents/SPEI analysis/actual files/events_modfuture_summer_1935_ex.csv")
#write.csv(modfuture_events_autumn_1935, "C:/Users/Documents/SPEI analysis/actual files/events_modfuture_autumn_1935_ex.csv")
#write.csv(modfuture_events_winter_1935, "C:/Users/Documents/SPEI analysis/actual files/events_modfuture_winter_1935_ex.csv")


#Calculate number of drought months overall
modpast_months_1935<-months_mod(spei_y_1935[["past"]])
modpresent_months_1935<-months_mod(spei_y_1935[["present"]])
modfuture_months_1935<-months_mod(spei_y_1935[["future"]])

#Save as .csv
#write.csv(modpast_months_1935, "C:/Users/Documents/SPEI analysis/actual files/months_mod_actual_past_1935.csv")
#write.csv(modpresent_months_1935, "months_mod_actual_present_1935.csv")
#write.csv(modfuture_months_1935, "C:/Users/Documents/SPEI analysis/actual files/months_mod_actual_future_1935.csv")


#Calculate number of drought months
spei_s_1935<-seasons(mod_1935_spei)
modpast_months_spring_1935<-months_mod(spei_s_1935[["past"]][["spring"]])
modpast_months_summer_1935<-months_mod(spei_s_1935[["past"]][["summer"]])
modpast_months_autumn_1935<-months_mod(spei_s_1935[["past"]][["autumn"]])
modpast_months_winter_1935<-months_mod(spei_s_1935[["past"]][["winter"]])

modpresent_months_spring_1935<-months_mod(spei_s_1935[["present"]][["spring"]])
modpresent_months_summer_1935<-months_mod(spei_s_1935[["present"]][["summer"]])
modpresent_months_autumn_1935<-months_mod(spei_s_1935[["present"]][["autumn"]])
modpresent_months_winter_1935<-months_mod(spei_s_1935[["present"]][["winter"]])

modfuture_months_spring_1935<-months_mod(spei_s_1935[["future"]][["spring"]])
modfuture_months_summer_1935<-months_mod(spei_s_1935[["future"]][["summer"]])
modfuture_months_autumn_1935<-months_mod(spei_s_1935[["future"]][["autumn"]])
modfuture_months_winter_1935<-months_mod(spei_s_1935[["future"]][["winter"]])

#Save as .csv
#write.csv(modpast_months_spring_1935, "C:/Users/Documents/SPEI analysis/actual files/months_modpast_spring_1935.csv")
#write.csv(modpast_months_summer_1935, "C:/Users/Documents/SPEI analysis/actual files/months_modpast_summer_1935.csv")
#write.csv(modpast_months_autumn_1935, "C:/Users/Documents/SPEI analysis/actual files/months_modpast_autumn_1935.csv")
#write.csv(modpast_months_winter_1935, "C:/Users/Documents/SPEI analysis/actual files/months_modpast_winter_1935.csv")

#write.csv(modpresent_months_spring_1935, "months_modpresent_spring_1935.csv")
#write.csv(modpresent_months_summer_1935, "months_modpresent_summer_1935.csv")
#write.csv(modpresent_months_autumn_1935, "months_modpresent_autumn_1935.csv")
#write.csv(modpresent_months_winter_1935, "months_modpresent_winter_1935.csv")

#write.csv(modfuture_months_spring_1935, "C:/Users/Documents/SPEI analysis/actual files/months_modfuture_spring_1935.csv")
#write.csv(modfuture_months_summer_1935, "C:/Users/Documents/SPEI analysis/actual files/months_modfuture_summer_1935.csv")
#write.csv(modfuture_months_autumn_1935, "C:/Users/Documents/SPEI analysis/actual files/months_modfuture_autumn_1935.csv")
#write.csv(modfuture_months_winter_1935, "C:/Users/Documents/SPEI analysis/actual files/months_modfuture_winter_1935.csv")


#Calculate change in number of drought events
changeevents_1935<-change(modpast_events_1935, modfuture_events_1935)

#Save as .csv
#write.csv(changeevents_1935, "C:/Users/Documents/SPEI analysis/change files/changeevents_1935_ex.csv")

#Calculate change in number of drought events seasonally
changeevents_spring_1935<-change(modpast_events_spring_1935, modfuture_events_spring_1935)
changeevents_summer_1935<-change(modpast_events_summer_1935, modfuture_events_summer_1935)
changeevents_autumn_1935<-change(modpast_events_autumn_1935, modfuture_events_autumn_1935)
changeevents_winter_1935<-change(modpast_events_winter_1935, modfuture_events_winter_1935)

#Save as .csv
#write.csv(changeevents_spring_1935, "C:/Users/Documents/SPEI analysis/change files/changeevents_spring_1935_ex.csv")
#write.csv(changeevents_summer_1935, "C:/Users/Documents/SPEI analysis/change files/changeevents_summer_1935_ex.csv")
#write.csv(changeevents_autumn_1935, "C:/Users/Documents/SPEI analysis/change files/changeevents_autumn_1935_ex.csv")
#write.csv(changeevents_winter_1935, "C:/Users/Documents/SPEI analysis/change files/changeevents_winter_1935_ex.csv")


#Calculate change in drought months
changemonths_1935<-change(modpast_months_1935, modfuture_months_1935)

#Save as .csv
#write.csv(changemonths_1935, "C:/Users/Documents/SPEI analysis/change files/changemonths_1935.csv")


#Calculate change in number of drought months seasonally
changemonths_spring_1935<-change(modpast_months_spring_1935, modfuture_months_spring_1935)
changemonths_summer_1935<-change(modpast_months_summer_1935, modfuture_months_summer_1935)
changemonths_autumn_1935<-change(modpast_months_autumn_1935, modfuture_months_autumn_1935)
changemonths_winter_1935<-change(modpast_months_winter_1935, modfuture_months_winter_1935)

#Save as .csv
#write.csv(changemonths_spring_1935, "C:/Users/Documents/SPEI analysis/change files/changemonths_spring_1935.csv")
#write.csv(changemonths_summer_1935, "C:/Users/Documents/SPEI analysis/change files/changemonths_summer_1935.csv")
#write.csv(changemonths_autumn_1935, "C:/Users/Documents/SPEI analysis/change files/changemonths_autumn_1935.csv")
#write.csv(changemonths_winter_1935, "C:/Users/Documents/SPEI analysis/change files/changemonths_winter_1935.csv")


########################################## Model output 2123 #########################################

#Import data
p_mod_2123<-read.csv("prcp_1980_2040_mod_12km_2123.csv",
                     header=F)
t_mod_2123<-read.csv("tas_1980_2040_mod_12km_2123.csv",
                     header=F)

#Reformat
mod_2123<-reformat(p_mod_2123, t_mod_2123)

#Change coordinates
mod_2123 <- lat_calc(mod_2123)

#Calculate bias
base_2123 <- past(mod_2123, obs)
mod_2123 <- bias(base_2123, mod_2123)

#Split into datasets by location
mod_2123_split <- split(mod_2123, list(mod_2123$easting, mod_2123$northing))

#Calculate SPEI 
mod_2123_spei<-spei_calc(mod_2123_split)


#Calculate number of drought events
spei_y_2123<-years(mod_2123_spei)
modpast_events_2123<-events_mod(spei_y_2123[["past"]])
modpresent_events_2123<-events_mod(spei_y_2123[["present"]])
modfuture_events_2123<-events_mod(spei_y_2123[["future"]])

#Save as .csv
#write.csv(modpast_events_2123, "C:/Users/Documents/SPEI analysis/actual files/events_modpast_2123_ex.csv")
write.csv(modpresent_events_2123, "events_modpresent_2123_ex.csv")
#write.csv(modfuture_events_2123, "C:/Users/Documents/SPEI analysis/actual files/events_modfuture_2123_ex.csv")

#Calculate number of drought events by season
spei_ps_2123<-period_season(mod_2123_spei)
modpast_events_spring_2123<-events_season(spei_ps_2123[["past.spring"]])
modpast_events_summer_2123<-events_season(spei_ps_2123[["past.summer"]])
modpast_events_autumn_2123<-events_season(spei_ps_2123[["past.autumn"]])
modpast_events_winter_2123<-events_season(spei_ps_2123[["past.winter"]])

modpresent_events_spring_2123<-events_season(spei_ps_2123[["present.spring"]])
modpresent_events_summer_2123<-events_season(spei_ps_2123[["present.summer"]])
modpresent_events_autumn_2123<-events_season(spei_ps_2123[["present.autumn"]])
modpresent_events_winter_2123<-events_season(spei_ps_2123[["present.winter"]])

modfuture_events_spring_2123<-events_season(spei_ps_2123[["future.spring"]])
modfuture_events_summer_2123<-events_season(spei_ps_2123[["future.summer"]])
modfuture_events_autumn_2123<-events_season(spei_ps_2123[["future.autumn"]])
modfuture_events_winter_2123<-events_season(spei_ps_2123[["future.winter"]])

#Save as .csv
#write.csv(modpast_events_spring_2123, "C:/Users/Documents/SPEI analysis/actual files/events_modpast_spring_2123_ex.csv")
#write.csv(modpast_events_summer_2123, "C:/Users/Documents/SPEI analysis/actual files/events_modpast_summer_2123_ex.csv")
#write.csv(modpast_events_autumn_2123, "C:/Users/Documents/SPEI analysis/actual files/events_modpast_autumn_2123_ex.csv")
#write.csv(modpast_events_winter_2123, "C:/Users/Documents/SPEI analysis/actual files/events_modpast_winter_2123_ex.csv")

#write.csv(modpresent_events_spring_2123, "events_modpresent_spring_2123_ex.csv")
#write.csv(modpresent_events_summer_2123, "events_modpresent_summer_2123_ex.csv")
#write.csv(modpresent_events_autumn_2123, "events_modpresent_autumn_2123_ex.csv")
#write.csv(modpresent_events_winter_2123, "events_modpresent_winter_2123_ex.csv")

#write.csv(modfuture_events_spring_2123, "C:/Users/Documents/SPEI analysis/actual files/events_modfuture_spring_2123_ex.csv")
#write.csv(modfuture_events_summer_2123, "C:/Users/Documents/SPEI analysis/actual files/events_modfuture_summer_2123_ex.csv")
#write.csv(modfuture_events_autumn_2123, "C:/Users/Documents/SPEI analysis/actual files/events_modfuture_autumn_2123_ex.csv")
#write.csv(modfuture_events_winter_2123, "C:/Users/Documents/SPEI analysis/actual files/events_modfuture_winter_2123_ex.csv")


#Calculate number of drought months overall
modpast_months_2123<-months_mod(spei_y_2123[["past"]])
modpresent_months_2123<-months_mod(spei_y_2123[["present"]])
modfuture_months_2123<-months_mod(spei_y_2123[["future"]])

#Save as .csv
#write.csv(modpast_months_2123, "C:/Users/Documents/SPEI analysis/actual files/months_mod_actual_past_2123.csv")
#write.csv(modpresent_months_2123, "months_mod_actual_present_2123.csv")
#write.csv(modfuture_months_2123, "C:/Users/Documents/SPEI analysis/actual files/months_mod_actual_future_2123.csv")


#Calculate number of drought months
spei_s_2123<-seasons(mod_2123_spei)
modpast_months_spring_2123<-months_mod(spei_s_2123[["past"]][["spring"]])
modpast_months_summer_2123<-months_mod(spei_s_2123[["past"]][["summer"]])
modpast_months_autumn_2123<-months_mod(spei_s_2123[["past"]][["autumn"]])
modpast_months_winter_2123<-months_mod(spei_s_2123[["past"]][["winter"]])

modpresent_months_spring_2123<-months_mod(spei_s_2123[["present"]][["spring"]])
modpresent_months_summer_2123<-months_mod(spei_s_2123[["present"]][["summer"]])
modpresent_months_autumn_2123<-months_mod(spei_s_2123[["present"]][["autumn"]])
modpresent_months_winter_2123<-months_mod(spei_s_2123[["present"]][["winter"]])

modfuture_months_spring_2123<-months_mod(spei_s_2123[["future"]][["spring"]])
modfuture_months_summer_2123<-months_mod(spei_s_2123[["future"]][["summer"]])
modfuture_months_autumn_2123<-months_mod(spei_s_2123[["future"]][["autumn"]])
modfuture_months_winter_2123<-months_mod(spei_s_2123[["future"]][["winter"]])

#Save as .csv
#write.csv(modpast_months_spring_2123, "C:/Users/Documents/SPEI analysis/actual files/months_modpast_spring_2123.csv")
#write.csv(modpast_months_summer_2123, "C:/Users/Documents/SPEI analysis/actual files/months_modpast_summer_2123.csv")
#write.csv(modpast_months_autumn_2123, "C:/Users/Documents/SPEI analysis/actual files/months_modpast_autumn_2123.csv")
#write.csv(modpast_months_winter_2123, "C:/Users/Documents/SPEI analysis/actual files/months_modpast_winter_2123.csv")

#write.csv(modpresent_months_spring_2123, "months_modpresent_spring_2123.csv")
#write.csv(modpresent_months_summer_2123, "months_modpresent_summer_2123.csv")
#write.csv(modpresent_months_autumn_2123, "months_modpresent_autumn_2123.csv")
#write.csv(modpresent_months_winter_2123, "months_modpresent_winter_2123.csv")

#write.csv(modfuture_months_spring_2123, "C:/Users/Documents/SPEI analysis/actual files/months_modfuture_spring_2123.csv")
#write.csv(modfuture_months_summer_2123, "C:/Users/Documents/SPEI analysis/actual files/months_modfuture_summer_2123.csv")
#write.csv(modfuture_months_autumn_2123, "C:/Users/Documents/SPEI analysis/actual files/months_modfuture_autumn_2123.csv")
#write.csv(modfuture_months_winter_2123, "C:/Users/Documents/SPEI analysis/actual files/months_modfuture_winter_2123.csv")


#Calculate change in number of drought events
changeevents_2123<-change(modpast_events_2123, modfuture_events_2123)

#Save as .csv
#write.csv(changeevents_2123, "C:/Users/Documents/SPEI analysis/change files/changeevents_2123_ex.csv")

#Calculate change in number of drought events seasonally
changeevents_spring_2123<-change(modpast_events_spring_2123, modfuture_events_spring_2123)
changeevents_summer_2123<-change(modpast_events_summer_2123, modfuture_events_summer_2123)
changeevents_autumn_2123<-change(modpast_events_autumn_2123, modfuture_events_autumn_2123)
changeevents_winter_2123<-change(modpast_events_winter_2123, modfuture_events_winter_2123)

#Save as .csv
#write.csv(changeevents_spring_2123, "C:/Users/Documents/SPEI analysis/change files/changeevents_spring_2123_ex.csv")
#write.csv(changeevents_summer_2123, "C:/Users/Documents/SPEI analysis/change files/changeevents_summer_2123_ex.csv")
#write.csv(changeevents_autumn_2123, "C:/Users/Documents/SPEI analysis/change files/changeevents_autumn_2123_ex.csv")
#write.csv(changeevents_winter_2123, "C:/Users/Documents/SPEI analysis/change files/changeevents_winter_2123_ex.csv")


#Calculate change in drought months
changemonths_2123<-change(modpast_months_2123, modfuture_months_2123)

#Save as .csv
#write.csv(changemonths_2123, "C:/Users/Documents/SPEI analysis/change files/changemonths_2123.csv")


#Calculate change in number of drought months seasonally
changemonths_spring_2123<-change(modpast_months_spring_2123, modfuture_months_spring_2123)
changemonths_summer_2123<-change(modpast_months_summer_2123, modfuture_months_summer_2123)
changemonths_autumn_2123<-change(modpast_months_autumn_2123, modfuture_months_autumn_2123)
changemonths_winter_2123<-change(modpast_months_winter_2123, modfuture_months_winter_2123)

#Save as .csv
#write.csv(changemonths_spring_2123, "C:/Users/Documents/SPEI analysis/change files/changemonths_spring_2123.csv")
#write.csv(changemonths_summer_2123, "C:/Users/Documents/SPEI analysis/change files/changemonths_summer_2123.csv")
#write.csv(changemonths_autumn_2123, "C:/Users/Documents/SPEI analysis/change files/changemonths_autumn_2123.csv")
#write.csv(changemonths_winter_2123, "C:/Users/Documents/SPEI analysis/change files/changemonths_winter_2123.csv")


########################################## Model output 2242 #########################################

#Import data
p_mod_2242<-read.csv("prcp_1980_2040_mod_12km_2242.csv",
                     header=F)
t_mod_2242<-read.csv("tas_1980_2040_mod_12km_2242.csv",
                     header=F)

#Reformat
mod_2242<-reformat(p_mod_2242, t_mod_2242)

#Change coordinates
mod_2242 <- lat_calc(mod_2242)

#Calculate bias
base_2242 <- past(mod_2242, obs)
mod_2242 <- bias(base_2242, mod_2242)

#Split into datasets by location
mod_2242_split <- split(mod_2242, list(mod_2242$easting, mod_2242$northing))

#Calculate SPEI 
mod_2242_spei<-spei_calc(mod_2242_split)


#Calculate number of drought events
spei_y_2242<-years(mod_2242_spei)
modpast_events_2242<-events_mod(spei_y_2242[["past"]])
modpresent_events_2242<-events_mod(spei_y_2242[["present"]])
modfuture_events_2242<-events_mod(spei_y_2242[["future"]])

#Save as .csv
#write.csv(modpast_events_2242, "C:/Users/Documents/SPEI analysis/actual files/events_modpast_2242_ex.csv")
write.csv(modpresent_events_2242, "events_modpresent_2242_ex.csv")
#write.csv(modfuture_events_2242, "C:/Users/Documents/SPEI analysis/actual files/events_modfuture_2242_ex.csv")

#Calculate number of drought events by season
spei_ps_2242<-period_season(mod_2242_spei)
modpast_events_spring_2242<-events_season(spei_ps_2242[["past.spring"]])
modpast_events_summer_2242<-events_season(spei_ps_2242[["past.summer"]])
modpast_events_autumn_2242<-events_season(spei_ps_2242[["past.autumn"]])
modpast_events_winter_2242<-events_season(spei_ps_2242[["past.winter"]])

modpresent_events_spring_2242<-events_season(spei_ps_2242[["present.spring"]])
modpresent_events_summer_2242<-events_season(spei_ps_2242[["present.summer"]])
modpresent_events_autumn_2242<-events_season(spei_ps_2242[["present.autumn"]])
modpresent_events_winter_2242<-events_season(spei_ps_2242[["present.winter"]])

modfuture_events_spring_2242<-events_season(spei_ps_2242[["future.spring"]])
modfuture_events_summer_2242<-events_season(spei_ps_2242[["future.summer"]])
modfuture_events_autumn_2242<-events_season(spei_ps_2242[["future.autumn"]])
modfuture_events_winter_2242<-events_season(spei_ps_2242[["future.winter"]])

#Save as .csv
#write.csv(modpast_events_spring_2242, "C:/Users/Documents/SPEI analysis/actual files/events_modpast_spring_2242_ex.csv")
#write.csv(modpast_events_summer_2242, "C:/Users/Documents/SPEI analysis/actual files/events_modpast_summer_2242_ex.csv")
#write.csv(modpast_events_autumn_2242, "C:/Users/Documents/SPEI analysis/actual files/events_modpast_autumn_2242_ex.csv")
#write.csv(modpast_events_winter_2242, "C:/Users/Documents/SPEI analysis/actual files/events_modpast_winter_2242_ex.csv")

#write.csv(modpresent_events_spring_2242, "events_modpresent_spring_2242_ex.csv")
#write.csv(modpresent_events_summer_2242, "events_modpresent_summer_2242_ex.csv")
#write.csv(modpresent_events_autumn_2242, "events_modpresent_autumn_2242_ex.csv")
#write.csv(modpresent_events_winter_2242, "events_modpresent_winter_2242_ex.csv")

#write.csv(modfuture_events_spring_2242, "C:/Users/Documents/SPEI analysis/actual files/events_modfuture_spring_2242_ex.csv")
#write.csv(modfuture_events_summer_2242, "C:/Users/Documents/SPEI analysis/actual files/events_modfuture_summer_2242_ex.csv")
#write.csv(modfuture_events_autumn_2242, "C:/Users/Documents/SPEI analysis/actual files/events_modfuture_autumn_2242_ex.csv")
#write.csv(modfuture_events_winter_2242, "C:/Users/Documents/SPEI analysis/actual files/events_modfuture_winter_2242_ex.csv")


#Calculate number of drought months overall
modpast_months_2242<-months_mod(spei_y_2242[["past"]])
modpresent_months_2242<-months_mod(spei_y_2242[["present"]])
modfuture_months_2242<-months_mod(spei_y_2242[["future"]])

#Save as .csv
#write.csv(modpast_months_2242, "C:/Users/Documents/SPEI analysis/actual files/months_mod_actual_past_2242.csv")
#write.csv(modpresent_months_2242, "months_mod_actual_present_2242.csv")
#write.csv(modfuture_months_2242, "C:/Users/Documents/SPEI analysis/actual files/months_mod_actual_future_2242.csv")


#Calculate number of drought months
spei_s_2242<-seasons(mod_2242_spei)
modpast_months_spring_2242<-months_mod(spei_s_2242[["past"]][["spring"]])
modpast_months_summer_2242<-months_mod(spei_s_2242[["past"]][["summer"]])
modpast_months_autumn_2242<-months_mod(spei_s_2242[["past"]][["autumn"]])
modpast_months_winter_2242<-months_mod(spei_s_2242[["past"]][["winter"]])

modpresent_months_spring_2242<-months_mod(spei_s_2242[["present"]][["spring"]])
modpresent_months_summer_2242<-months_mod(spei_s_2242[["present"]][["summer"]])
modpresent_months_autumn_2242<-months_mod(spei_s_2242[["present"]][["autumn"]])
modpresent_months_winter_2242<-months_mod(spei_s_2242[["present"]][["winter"]])

modfuture_months_spring_2242<-months_mod(spei_s_2242[["future"]][["spring"]])
modfuture_months_summer_2242<-months_mod(spei_s_2242[["future"]][["summer"]])
modfuture_months_autumn_2242<-months_mod(spei_s_2242[["future"]][["autumn"]])
modfuture_months_winter_2242<-months_mod(spei_s_2242[["future"]][["winter"]])

#Save as .csv
#write.csv(modpast_months_spring_2242, "C:/Users/Documents/SPEI analysis/actual files/months_modpast_spring_2242.csv")
#write.csv(modpast_months_summer_2242, "C:/Users/Documents/SPEI analysis/actual files/months_modpast_summer_2242.csv")
#write.csv(modpast_months_autumn_2242, "C:/Users/Documents/SPEI analysis/actual files/months_modpast_autumn_2242.csv")
#write.csv(modpast_months_winter_2242, "C:/Users/Documents/SPEI analysis/actual files/months_modpast_winter_2242.csv")

#write.csv(modpresent_months_spring_2242, "months_modpresent_spring_2242.csv")
#write.csv(modpresent_months_summer_2242, "months_modpresent_summer_2242.csv")
#write.csv(modpresent_months_autumn_2242, "months_modpresent_autumn_2242.csv")
#write.csv(modpresent_months_winter_2242, "months_modpresent_winter_2242.csv")

#write.csv(modfuture_months_spring_2242, "C:/Users/Documents/SPEI analysis/actual files/months_modfuture_spring_2242.csv")
#write.csv(modfuture_months_summer_2242, "C:/Users/Documents/SPEI analysis/actual files/months_modfuture_summer_2242.csv")
#write.csv(modfuture_months_autumn_2242, "C:/Users/Documents/SPEI analysis/actual files/months_modfuture_autumn_2242.csv")
#write.csv(modfuture_months_winter_2242, "C:/Users/Documents/SPEI analysis/actual files/months_modfuture_winter_2242.csv")


#Calculate change in number of drought events
changeevents_2242<-change(modpast_events_2242, modfuture_events_2242)

#Save as .csv
#write.csv(changeevents_2242, "C:/Users/Documents/SPEI analysis/change files/changeevents_2242_ex.csv")

#Calculate change in number of drought events seasonally
changeevents_spring_2242<-change(modpast_events_spring_2242, modfuture_events_spring_2242)
changeevents_summer_2242<-change(modpast_events_summer_2242, modfuture_events_summer_2242)
changeevents_autumn_2242<-change(modpast_events_autumn_2242, modfuture_events_autumn_2242)
changeevents_winter_2242<-change(modpast_events_winter_2242, modfuture_events_winter_2242)

#Save as .csv
#write.csv(changeevents_spring_2242, "C:/Users/Documents/SPEI analysis/change files/changeevents_spring_2242_ex.csv")
#write.csv(changeevents_summer_2242, "C:/Users/Documents/SPEI analysis/change files/changeevents_summer_2242_ex.csv")
#write.csv(changeevents_autumn_2242, "C:/Users/Documents/SPEI analysis/change files/changeevents_autumn_2242_ex.csv")
#write.csv(changeevents_winter_2242, "C:/Users/Documents/SPEI analysis/change files/changeevents_winter_2242_ex.csv")


#Calculate change in drought months
changemonths_2242<-change(modpast_months_2242, modfuture_months_2242)

#Save as .csv
#write.csv(changemonths_2242, "C:/Users/Documents/SPEI analysis/change files/changemonths_2242.csv")


#Calculate change in number of drought months seasonally
changemonths_spring_2242<-change(modpast_months_spring_2242, modfuture_months_spring_2242)
changemonths_summer_2242<-change(modpast_months_summer_2242, modfuture_months_summer_2242)
changemonths_autumn_2242<-change(modpast_months_autumn_2242, modfuture_months_autumn_2242)
changemonths_winter_2242<-change(modpast_months_winter_2242, modfuture_months_winter_2242)

#Save as .csv
#write.csv(changemonths_spring_2242, "C:/Users/Documents/SPEI analysis/change files/changemonths_spring_2242.csv")
#write.csv(changemonths_summer_2242, "C:/Users/Documents/SPEI analysis/change files/changemonths_summer_2242.csv")
#write.csv(changemonths_autumn_2242, "C:/Users/Documents/SPEI analysis/change files/changemonths_autumn_2242.csv")
#write.csv(changemonths_winter_2242, "C:/Users/Documents/SPEI analysis/change files/changemonths_winter_2242.csv")


########################################## Model output 2305 #########################################

#Import data
p_mod_2305<-read.csv("prcp_1980_2040_mod_12km_2305.csv",
                     header=F)
t_mod_2305<-read.csv("tas_1980_2040_mod_12km_2305.csv",
                     header=F)

#Reformat
mod_2305<-reformat(p_mod_2305, t_mod_2305)

#Change coordinates
mod_2305 <- lat_calc(mod_2305)

#Calculate bias
base_2305 <- past(mod_2305, obs)
mod_2305 <- bias(base_2305, mod_2305)

#Split into datasets by location
mod_2305_split <- split(mod_2305, list(mod_2305$easting, mod_2305$northing))

#Calculate SPEI 
mod_2305_spei<-spei_calc(mod_2305_split)


#Calculate number of drought events
spei_y_2305<-years(mod_2305_spei)
modpast_events_2305<-events_mod(spei_y_2305[["past"]])
modpresent_events_2305<-events_mod(spei_y_2305[["present"]])
modfuture_events_2305<-events_mod(spei_y_2305[["future"]])

#Save as .csv
#write.csv(modpast_events_2305, "C:/Users/Documents/SPEI analysis/actual files/events_modpast_2305_ex.csv")
write.csv(modpresent_events_2305, "events_modpresent_2305_ex.csv")
#write.csv(modfuture_events_2305, "C:/Users/Documents/SPEI analysis/actual files/events_modfuture_2305_ex.csv")

#Calculate number of drought events by season
spei_ps_2305<-period_season(mod_2305_spei)
modpast_events_spring_2305<-events_season(spei_ps_2305[["past.spring"]])
modpast_events_summer_2305<-events_season(spei_ps_2305[["past.summer"]])
modpast_events_autumn_2305<-events_season(spei_ps_2305[["past.autumn"]])
modpast_events_winter_2305<-events_season(spei_ps_2305[["past.winter"]])

modpresent_events_spring_2305<-events_season(spei_ps_2305[["present.spring"]])
modpresent_events_summer_2305<-events_season(spei_ps_2305[["present.summer"]])
modpresent_events_autumn_2305<-events_season(spei_ps_2305[["present.autumn"]])
modpresent_events_winter_2305<-events_season(spei_ps_2305[["present.winter"]])

modfuture_events_spring_2305<-events_season(spei_ps_2305[["future.spring"]])
modfuture_events_summer_2305<-events_season(spei_ps_2305[["future.summer"]])
modfuture_events_autumn_2305<-events_season(spei_ps_2305[["future.autumn"]])
modfuture_events_winter_2305<-events_season(spei_ps_2305[["future.winter"]])

#Save as .csv
#write.csv(modpast_events_spring_2305, "C:/Users/Documents/SPEI analysis/actual files/events_modpast_spring_2305_ex.csv")
#write.csv(modpast_events_summer_2305, "C:/Users/Documents/SPEI analysis/actual files/events_modpast_summer_2305_ex.csv")
#write.csv(modpast_events_autumn_2305, "C:/Users/Documents/SPEI analysis/actual files/events_modpast_autumn_2305_ex.csv")
#write.csv(modpast_events_winter_2305, "C:/Users/Documents/SPEI analysis/actual files/events_modpast_winter_2305_ex.csv")

#write.csv(modpresent_events_spring_2305, "events_modpresent_spring_2305_ex.csv")
#write.csv(modpresent_events_summer_2305, "events_modpresent_summer_2305_ex.csv")
#write.csv(modpresent_events_autumn_2305, "events_modpresent_autumn_2305_ex.csv")
#write.csv(modpresent_events_winter_2305, "events_modpresent_winter_2305_ex.csv")

#write.csv(modfuture_events_spring_2305, "C:/Users/Documents/SPEI analysis/actual files/events_modfuture_spring_2305_ex.csv")
#write.csv(modfuture_events_summer_2305, "C:/Users/Documents/SPEI analysis/actual files/events_modfuture_summer_2305_ex.csv")
#write.csv(modfuture_events_autumn_2305, "C:/Users/Documents/SPEI analysis/actual files/events_modfuture_autumn_2305_ex.csv")
#write.csv(modfuture_events_winter_2305, "C:/Users/Documents/SPEI analysis/actual files/events_modfuture_winter_2305_ex.csv")


#Calculate number of drought months overall
modpast_months_2305<-months_mod(spei_y_2305[["past"]])
modpresent_months_2305<-months_mod(spei_y_2305[["present"]])
modfuture_months_2305<-months_mod(spei_y_2305[["future"]])

#Save as .csv
#write.csv(modpast_months_2305, "C:/Users/Documents/SPEI analysis/actual files/months_mod_actual_past_2305.csv")
#write.csv(modpresent_months_2305, "months_mod_actual_present_2305.csv")
#write.csv(modfuture_months_2305, "C:/Users/Documents/SPEI analysis/actual files/months_mod_actual_future_2305.csv")


#Calculate number of drought months
spei_s_2305<-seasons(mod_2305_spei)
modpast_months_spring_2305<-months_mod(spei_s_2305[["past"]][["spring"]])
modpast_months_summer_2305<-months_mod(spei_s_2305[["past"]][["summer"]])
modpast_months_autumn_2305<-months_mod(spei_s_2305[["past"]][["autumn"]])
modpast_months_winter_2305<-months_mod(spei_s_2305[["past"]][["winter"]])

modpresent_months_spring_2305<-months_mod(spei_s_2305[["present"]][["spring"]])
modpresent_months_summer_2305<-months_mod(spei_s_2305[["present"]][["summer"]])
modpresent_months_autumn_2305<-months_mod(spei_s_2305[["present"]][["autumn"]])
modpresent_months_winter_2305<-months_mod(spei_s_2305[["present"]][["winter"]])

modfuture_months_spring_2305<-months_mod(spei_s_2305[["future"]][["spring"]])
modfuture_months_summer_2305<-months_mod(spei_s_2305[["future"]][["summer"]])
modfuture_months_autumn_2305<-months_mod(spei_s_2305[["future"]][["autumn"]])
modfuture_months_winter_2305<-months_mod(spei_s_2305[["future"]][["winter"]])

#Save as .csv
#write.csv(modpast_months_spring_2305, "C:/Users/Documents/SPEI analysis/actual files/months_modpast_spring_2305.csv")
#write.csv(modpast_months_summer_2305, "C:/Users/Documents/SPEI analysis/actual files/months_modpast_summer_2305.csv")
#write.csv(modpast_months_autumn_2305, "C:/Users/Documents/SPEI analysis/actual files/months_modpast_autumn_2305.csv")
#write.csv(modpast_months_winter_2305, "C:/Users/Documents/SPEI analysis/actual files/months_modpast_winter_2305.csv")

#write.csv(modpresent_months_spring_2305, "months_modpresent_spring_2305.csv")
#write.csv(modpresent_months_summer_2305, "months_modpresent_summer_2305.csv")
#write.csv(modpresent_months_autumn_2305, "months_modpresent_autumn_2305.csv")
#write.csv(modpresent_months_winter_2305, "months_modpresent_winter_2305.csv")

#write.csv(modfuture_months_spring_2305, "C:/Users/Documents/SPEI analysis/actual files/months_modfuture_spring_2305.csv")
#write.csv(modfuture_months_summer_2305, "C:/Users/Documents/SPEI analysis/actual files/months_modfuture_summer_2305.csv")
#write.csv(modfuture_months_autumn_2305, "C:/Users/Documents/SPEI analysis/actual files/months_modfuture_autumn_2305.csv")
#write.csv(modfuture_months_winter_2305, "C:/Users/Documents/SPEI analysis/actual files/months_modfuture_winter_2305.csv")


#Calculate change in number of drought events
changeevents_2305<-change(modpast_events_2305, modfuture_events_2305)

#Save as .csv
#write.csv(changeevents_2305, "C:/Users/Documents/SPEI analysis/change files/changeevents_2305_ex.csv")

#Calculate change in number of drought events seasonally
changeevents_spring_2305<-change(modpast_events_spring_2305, modfuture_events_spring_2305)
changeevents_summer_2305<-change(modpast_events_summer_2305, modfuture_events_summer_2305)
changeevents_autumn_2305<-change(modpast_events_autumn_2305, modfuture_events_autumn_2305)
changeevents_winter_2305<-change(modpast_events_winter_2305, modfuture_events_winter_2305)

#Save as .csv
#write.csv(changeevents_spring_2305, "C:/Users/Documents/SPEI analysis/change files/changeevents_spring_2305_ex.csv")
#write.csv(changeevents_summer_2305, "C:/Users/Documents/SPEI analysis/change files/changeevents_summer_2305_ex.csv")
#write.csv(changeevents_autumn_2305, "C:/Users/Documents/SPEI analysis/change files/changeevents_autumn_2305_ex.csv")
#write.csv(changeevents_winter_2305, "C:/Users/Documents/SPEI analysis/change files/changeevents_winter_2305_ex.csv")


#Calculate change in drought months
changemonths_2305<-change(modpast_months_2305, modfuture_months_2305)

#Save as .csv
#write.csv(changemonths_2305, "C:/Users/Documents/SPEI analysis/change files/changemonths_2305.csv")


#Calculate change in number of drought months seasonally
changemonths_spring_2305<-change(modpast_months_spring_2305, modfuture_months_spring_2305)
changemonths_summer_2305<-change(modpast_months_summer_2305, modfuture_months_summer_2305)
changemonths_autumn_2305<-change(modpast_months_autumn_2305, modfuture_months_autumn_2305)
changemonths_winter_2305<-change(modpast_months_winter_2305, modfuture_months_winter_2305)

#Save as .csv
#write.csv(changemonths_spring_2305, "C:/Users/Documents/SPEI analysis/change files/changemonths_spring_2305.csv")
#write.csv(changemonths_summer_2305, "C:/Users/Documents/SPEI analysis/change files/changemonths_summer_2305.csv")
#write.csv(changemonths_autumn_2305, "C:/Users/Documents/SPEI analysis/change files/changemonths_autumn_2305.csv")
#write.csv(changemonths_winter_2305, "C:/Users/Documents/SPEI analysis/change files/changemonths_winter_2305.csv")


########################################## Model output 2335 #########################################

#Import data
p_mod_2335<-read.csv("prcp_1980_2040_mod_12km_2335.csv",
                     header=F)
t_mod_2335<-read.csv("tas_1980_2040_mod_12km_2335.csv",
                     header=F)

#Reformat
mod_2335<-reformat(p_mod_2335, t_mod_2335)

#Change coordinates
mod_2335 <- lat_calc(mod_2335)

#Calculate bias
base_2335 <- past(mod_2335, obs)
mod_2335 <- bias(base_2335, mod_2335)

#Split into datasets by location
mod_2335_split <- split(mod_2335, list(mod_2335$easting, mod_2335$northing))

#Calculate SPEI 
mod_2335_spei<-spei_calc(mod_2335_split)


#Calculate number of drought events
spei_y_2335<-years(mod_2335_spei)
modpast_events_2335<-events_mod(spei_y_2335[["past"]])
modpresent_events_2335<-events_mod(spei_y_2335[["present"]])
modfuture_events_2335<-events_mod(spei_y_2335[["future"]])

#Save as .csv
#write.csv(modpast_events_2335, "C:/Users/Documents/SPEI analysis/actual files/events_modpast_2335_ex.csv")
write.csv(modpresent_events_2335, "events_modpresent_2335_ex.csv")
#write.csv(modfuture_events_2335, "C:/Users/Documents/SPEI analysis/actual files/events_modfuture_2335_ex.csv")

#Calculate number of drought events by season
spei_ps_2335<-period_season(mod_2335_spei)
modpast_events_spring_2335<-events_season(spei_ps_2335[["past.spring"]])
modpast_events_summer_2335<-events_season(spei_ps_2335[["past.summer"]])
modpast_events_autumn_2335<-events_season(spei_ps_2335[["past.autumn"]])
modpast_events_winter_2335<-events_season(spei_ps_2335[["past.winter"]])

modpresent_events_spring_2335<-events_season(spei_ps_2335[["present.spring"]])
modpresent_events_summer_2335<-events_season(spei_ps_2335[["present.summer"]])
modpresent_events_autumn_2335<-events_season(spei_ps_2335[["present.autumn"]])
modpresent_events_winter_2335<-events_season(spei_ps_2335[["present.winter"]])

modfuture_events_spring_2335<-events_season(spei_ps_2335[["future.spring"]])
modfuture_events_summer_2335<-events_season(spei_ps_2335[["future.summer"]])
modfuture_events_autumn_2335<-events_season(spei_ps_2335[["future.autumn"]])
modfuture_events_winter_2335<-events_season(spei_ps_2335[["future.winter"]])

#Save as .csv
#write.csv(modpast_events_spring_2335, "C:/Users/Documents/SPEI analysis/actual files/events_modpast_spring_2335_ex.csv")
#write.csv(modpast_events_summer_2335, "C:/Users/Documents/SPEI analysis/actual files/events_modpast_summer_2335_ex.csv")
#write.csv(modpast_events_autumn_2335, "C:/Users/Documents/SPEI analysis/actual files/events_modpast_autumn_2335_ex.csv")
#write.csv(modpast_events_winter_2335, "C:/Users/Documents/SPEI analysis/actual files/events_modpast_winter_2335_ex.csv")

#write.csv(modpresent_events_spring_2335, "events_modpresent_spring_2335_ex.csv")
#write.csv(modpresent_events_summer_2335, "events_modpresent_summer_2335_ex.csv")
#write.csv(modpresent_events_autumn_2335, "events_modpresent_autumn_2335_ex.csv")
#write.csv(modpresent_events_winter_2335, "events_modpresent_winter_2335_ex.csv")

#write.csv(modfuture_events_spring_2335, "C:/Users/Documents/SPEI analysis/actual files/events_modfuture_spring_2335_ex.csv")
#write.csv(modfuture_events_summer_2335, "C:/Users/Documents/SPEI analysis/actual files/events_modfuture_summer_2335_ex.csv")
#write.csv(modfuture_events_autumn_2335, "C:/Users/Documents/SPEI analysis/actual files/events_modfuture_autumn_2335_ex.csv")
#write.csv(modfuture_events_winter_2335, "C:/Users/Documents/SPEI analysis/actual files/events_modfuture_winter_2335_ex.csv")


#Calculate number of drought months overall
modpast_months_2335<-months_mod(spei_y_2335[["past"]])
modpresent_months_2335<-months_mod(spei_y_2335[["present"]])
modfuture_months_2335<-months_mod(spei_y_2335[["future"]])

#Save as .csv
#write.csv(modpast_months_2335, "C:/Users/Documents/SPEI analysis/actual files/months_mod_actual_past_2335.csv")
#write.csv(modpresent_months_2335, "months_mod_actual_present_2335.csv")
#write.csv(modfuture_months_2335, "C:/Users/Documents/SPEI analysis/actual files/months_mod_actual_future_2335.csv")


#Calculate number of drought months
spei_s_2335<-seasons(mod_2335_spei)
modpast_months_spring_2335<-months_mod(spei_s_2335[["past"]][["spring"]])
modpast_months_summer_2335<-months_mod(spei_s_2335[["past"]][["summer"]])
modpast_months_autumn_2335<-months_mod(spei_s_2335[["past"]][["autumn"]])
modpast_months_winter_2335<-months_mod(spei_s_2335[["past"]][["winter"]])

modpresent_months_spring_2335<-months_mod(spei_s_2335[["present"]][["spring"]])
modpresent_months_summer_2335<-months_mod(spei_s_2335[["present"]][["summer"]])
modpresent_months_autumn_2335<-months_mod(spei_s_2335[["present"]][["autumn"]])
modpresent_months_winter_2335<-months_mod(spei_s_2335[["present"]][["winter"]])

modfuture_months_spring_2335<-months_mod(spei_s_2335[["future"]][["spring"]])
modfuture_months_summer_2335<-months_mod(spei_s_2335[["future"]][["summer"]])
modfuture_months_autumn_2335<-months_mod(spei_s_2335[["future"]][["autumn"]])
modfuture_months_winter_2335<-months_mod(spei_s_2335[["future"]][["winter"]])

#Save as .csv
#write.csv(modpast_months_spring_2335, "C:/Users/Documents/SPEI analysis/actual files/months_modpast_spring_2335.csv")
#write.csv(modpast_months_summer_2335, "C:/Users/Documents/SPEI analysis/actual files/months_modpast_summer_2335.csv")
#write.csv(modpast_months_autumn_2335, "C:/Users/Documents/SPEI analysis/actual files/months_modpast_autumn_2335.csv")
#write.csv(modpast_months_winter_2335, "C:/Users/Documents/SPEI analysis/actual files/months_modpast_winter_2335.csv")

#write.csv(modpresent_months_spring_2335, "months_modpresent_spring_2335.csv")
#write.csv(modpresent_months_summer_2335, "months_modpresent_summer_2335.csv")
#write.csv(modpresent_months_autumn_2335, "months_modpresent_autumn_2335.csv")
#write.csv(modpresent_months_winter_2335, "months_modpresent_winter_2335.csv")

#write.csv(modfuture_months_spring_2335, "C:/Users/Documents/SPEI analysis/actual files/months_modfuture_spring_2335.csv")
#write.csv(modfuture_months_summer_2335, "C:/Users/Documents/SPEI analysis/actual files/months_modfuture_summer_2335.csv")
#write.csv(modfuture_months_autumn_2335, "C:/Users/Documents/SPEI analysis/actual files/months_modfuture_autumn_2335.csv")
#write.csv(modfuture_months_winter_2335, "C:/Users/Documents/SPEI analysis/actual files/months_modfuture_winter_2335.csv")


#Calculate change in number of drought events
changeevents_2335<-change(modpast_events_2335, modfuture_events_2335)

#Save as .csv
#write.csv(changeevents_2335, "C:/Users/Documents/SPEI analysis/change files/changeevents_2335_ex.csv")

#Calculate change in number of drought events seasonally
changeevents_spring_2335<-change(modpast_events_spring_2335, modfuture_events_spring_2335)
changeevents_summer_2335<-change(modpast_events_summer_2335, modfuture_events_summer_2335)
changeevents_autumn_2335<-change(modpast_events_autumn_2335, modfuture_events_autumn_2335)
changeevents_winter_2335<-change(modpast_events_winter_2335, modfuture_events_winter_2335)

#Save as .csv
#write.csv(changeevents_spring_2335, "C:/Users/Documents/SPEI analysis/change files/changeevents_spring_2335_ex.csv")
#write.csv(changeevents_summer_2335, "C:/Users/Documents/SPEI analysis/change files/changeevents_summer_2335_ex.csv")
#write.csv(changeevents_autumn_2335, "C:/Users/Documents/SPEI analysis/change files/changeevents_autumn_2335_ex.csv")
#write.csv(changeevents_winter_2335, "C:/Users/Documents/SPEI analysis/change files/changeevents_winter_2335_ex.csv")


#Calculate change in drought months
changemonths_2335<-change(modpast_months_2335, modfuture_months_2335)

#Save as .csv
#write.csv(changemonths_2335, "C:/Users/Documents/SPEI analysis/change files/changemonths_2335.csv")


#Calculate change in number of drought months seasonally
changemonths_spring_2335<-change(modpast_months_spring_2335, modfuture_months_spring_2335)
changemonths_summer_2335<-change(modpast_months_summer_2335, modfuture_months_summer_2335)
changemonths_autumn_2335<-change(modpast_months_autumn_2335, modfuture_months_autumn_2335)
changemonths_winter_2335<-change(modpast_months_winter_2335, modfuture_months_winter_2335)

#Save as .csv
#write.csv(changemonths_spring_2335, "C:/Users/Documents/SPEI analysis/change files/changemonths_spring_2335.csv")
#write.csv(changemonths_summer_2335, "C:/Users/Documents/SPEI analysis/change files/changemonths_summer_2335.csv")
#write.csv(changemonths_autumn_2335, "C:/Users/Documents/SPEI analysis/change files/changemonths_autumn_2335.csv")
#write.csv(changemonths_winter_2335, "C:/Users/Documents/SPEI analysis/change files/changemonths_winter_2335.csv")


########################################## Model output 2491 #########################################

#Import data
p_mod_2491<-read.csv("prcp_1980_2040_mod_12km_2491.csv",
                     header=F)
t_mod_2491<-read.csv("tas_1980_2040_mod_12km_2491.csv",
                     header=F)

#Reformat
mod_2491<-reformat(p_mod_2491, t_mod_2491)

#Change coordinates
mod_2491 <- lat_calc(mod_2491)

#Calculate bias
base_2491 <- past(mod_2491, obs)
mod_2491 <- bias(base_2491, mod_2491)

#Split into datasets by location
mod_2491_split <- split(mod_2491, list(mod_2491$easting, mod_2491$northing))

#Calculate SPEI 
mod_2491_spei<-spei_calc(mod_2491_split)


#Calculate number of drought events
spei_y_2491<-years(mod_2491_spei)
modpast_events_2491<-events_mod(spei_y_2491[["past"]])
modpresent_events_2491<-events_mod(spei_y_2491[["present"]])
modfuture_events_2491<-events_mod(spei_y_2491[["future"]])

#Save as .csv
#write.csv(modpast_events_2491, "C:/Users/Documents/SPEI analysis/actual files/events_modpast_2491_ex.csv")
write.csv(modpresent_events_2491, "events_modpresent_2491_ex.csv")
#write.csv(modfuture_events_2491, "C:/Users/Documents/SPEI analysis/actual files/events_modfuture_2491_ex.csv")

#Calculate number of drought events by season
spei_ps_2491<-period_season(mod_2491_spei)
modpast_events_spring_2491<-events_season(spei_ps_2491[["past.spring"]])
modpast_events_summer_2491<-events_season(spei_ps_2491[["past.summer"]])
modpast_events_autumn_2491<-events_season(spei_ps_2491[["past.autumn"]])
modpast_events_winter_2491<-events_season(spei_ps_2491[["past.winter"]])

modpresent_events_spring_2491<-events_season(spei_ps_2491[["present.spring"]])
modpresent_events_summer_2491<-events_season(spei_ps_2491[["present.summer"]])
modpresent_events_autumn_2491<-events_season(spei_ps_2491[["present.autumn"]])
modpresent_events_winter_2491<-events_season(spei_ps_2491[["present.winter"]])

modfuture_events_spring_2491<-events_season(spei_ps_2491[["future.spring"]])
modfuture_events_summer_2491<-events_season(spei_ps_2491[["future.summer"]])
modfuture_events_autumn_2491<-events_season(spei_ps_2491[["future.autumn"]])
modfuture_events_winter_2491<-events_season(spei_ps_2491[["future.winter"]])

#Save as .csv
#write.csv(modpast_events_spring_2491, "C:/Users/Documents/SPEI analysis/actual files/events_modpast_spring_2491_ex.csv")
#write.csv(modpast_events_summer_2491, "C:/Users/Documents/SPEI analysis/actual files/events_modpast_summer_2491_ex.csv")
#write.csv(modpast_events_autumn_2491, "C:/Users/Documents/SPEI analysis/actual files/events_modpast_autumn_2491_ex.csv")
#write.csv(modpast_events_winter_2491, "C:/Users/Documents/SPEI analysis/actual files/events_modpast_winter_2491_ex.csv")

#write.csv(modpresent_events_spring_2491, "events_modpresent_spring_2491_ex.csv")
#write.csv(modpresent_events_summer_2491, "events_modpresent_summer_2491_ex.csv")
#write.csv(modpresent_events_autumn_2491, "events_modpresent_autumn_2491_ex.csv")
#write.csv(modpresent_events_winter_2491, "events_modpresent_winter_2491_ex.csv")

#write.csv(modfuture_events_spring_2491, "C:/Users/Documents/SPEI analysis/actual files/events_modfuture_spring_2491_ex.csv")
#write.csv(modfuture_events_summer_2491, "C:/Users/Documents/SPEI analysis/actual files/events_modfuture_summer_2491_ex.csv")
#write.csv(modfuture_events_autumn_2491, "C:/Users/Documents/SPEI analysis/actual files/events_modfuture_autumn_2491_ex.csv")
#write.csv(modfuture_events_winter_2491, "C:/Users/Documents/SPEI analysis/actual files/events_modfuture_winter_2491_ex.csv")


#Calculate number of drought months overall
modpast_months_2491<-months_mod(spei_y_2491[["past"]])
modpresent_months_2491<-months_mod(spei_y_2491[["present"]])
modfuture_months_2491<-months_mod(spei_y_2491[["future"]])

#Save as .csv
#write.csv(modpast_months_2491, "C:/Users/Documents/SPEI analysis/actual files/months_mod_actual_past_2491.csv")
#write.csv(modpresent_months_2491, "months_mod_actual_present_2491.csv")
#write.csv(modfuture_months_2491, "C:/Users/Documents/SPEI analysis/actual files/months_mod_actual_future_2491.csv")


#Calculate number of drought months
spei_s_2491<-seasons(mod_2491_spei)
modpast_months_spring_2491<-months_mod(spei_s_2491[["past"]][["spring"]])
modpast_months_summer_2491<-months_mod(spei_s_2491[["past"]][["summer"]])
modpast_months_autumn_2491<-months_mod(spei_s_2491[["past"]][["autumn"]])
modpast_months_winter_2491<-months_mod(spei_s_2491[["past"]][["winter"]])

modpresent_months_spring_2491<-months_mod(spei_s_2491[["present"]][["spring"]])
modpresent_months_summer_2491<-months_mod(spei_s_2491[["present"]][["summer"]])
modpresent_months_autumn_2491<-months_mod(spei_s_2491[["present"]][["autumn"]])
modpresent_months_winter_2491<-months_mod(spei_s_2491[["present"]][["winter"]])

modfuture_months_spring_2491<-months_mod(spei_s_2491[["future"]][["spring"]])
modfuture_months_summer_2491<-months_mod(spei_s_2491[["future"]][["summer"]])
modfuture_months_autumn_2491<-months_mod(spei_s_2491[["future"]][["autumn"]])
modfuture_months_winter_2491<-months_mod(spei_s_2491[["future"]][["winter"]])

#Save as .csv
#write.csv(modpast_months_spring_2491, "C:/Users/Documents/SPEI analysis/actual files/months_modpast_spring_2491.csv")
#write.csv(modpast_months_summer_2491, "C:/Users/Documents/SPEI analysis/actual files/months_modpast_summer_2491.csv")
#write.csv(modpast_months_autumn_2491, "C:/Users/Documents/SPEI analysis/actual files/months_modpast_autumn_2491.csv")
#write.csv(modpast_months_winter_2491, "C:/Users/Documents/SPEI analysis/actual files/months_modpast_winter_2491.csv")

#write.csv(modpresent_months_spring_2491, "months_modpresent_spring_2491.csv")
#write.csv(modpresent_months_summer_2491, "months_modpresent_summer_2491.csv")
#write.csv(modpresent_months_autumn_2491, "months_modpresent_autumn_2491.csv")
#write.csv(modpresent_months_winter_2491, "months_modpresent_winter_2491.csv")

#write.csv(modfuture_months_spring_2491, "C:/Users/Documents/SPEI analysis/actual files/months_modfuture_spring_2491.csv")
#write.csv(modfuture_months_summer_2491, "C:/Users/Documents/SPEI analysis/actual files/months_modfuture_summer_2491.csv")
#write.csv(modfuture_months_autumn_2491, "C:/Users/Documents/SPEI analysis/actual files/months_modfuture_autumn_2491.csv")
#write.csv(modfuture_months_winter_2491, "C:/Users/Documents/SPEI analysis/actual files/months_modfuture_winter_2491.csv")


#Calculate change in number of drought events
changeevents_2491<-change(modpast_events_2491, modfuture_events_2491)

#Save as .csv
#write.csv(changeevents_2491, "C:/Users/Documents/SPEI analysis/change files/changeevents_2491_ex.csv")

#Calculate change in number of drought events seasonally
changeevents_spring_2491<-change(modpast_events_spring_2491, modfuture_events_spring_2491)
changeevents_summer_2491<-change(modpast_events_summer_2491, modfuture_events_summer_2491)
changeevents_autumn_2491<-change(modpast_events_autumn_2491, modfuture_events_autumn_2491)
changeevents_winter_2491<-change(modpast_events_winter_2491, modfuture_events_winter_2491)

#Save as .csv
#write.csv(changeevents_spring_2491, "C:/Users/Documents/SPEI analysis/change files/changeevents_spring_2491_ex.csv")
#write.csv(changeevents_summer_2491, "C:/Users/Documents/SPEI analysis/change files/changeevents_summer_2491_ex.csv")
#write.csv(changeevents_autumn_2491, "C:/Users/Documents/SPEI analysis/change files/changeevents_autumn_2491_ex.csv")
#write.csv(changeevents_winter_2491, "C:/Users/Documents/SPEI analysis/change files/changeevents_winter_2491_ex.csv")


#Calculate change in drought months
changemonths_2491<-change(modpast_months_2491, modfuture_months_2491)

#Save as .csv
#write.csv(changemonths_2491, "C:/Users/Documents/SPEI analysis/change files/changemonths_2491.csv")


#Calculate change in number of drought months seasonally
changemonths_spring_2491<-change(modpast_months_spring_2491, modfuture_months_spring_2491)
changemonths_summer_2491<-change(modpast_months_summer_2491, modfuture_months_summer_2491)
changemonths_autumn_2491<-change(modpast_months_autumn_2491, modfuture_months_autumn_2491)
changemonths_winter_2491<-change(modpast_months_winter_2491, modfuture_months_winter_2491)

#Save as .csv
#write.csv(changemonths_spring_2491, "C:/Users/Documents/SPEI analysis/change files/changemonths_spring_2491.csv")
#write.csv(changemonths_summer_2491, "C:/Users/Documents/SPEI analysis/change files/changemonths_summer_2491.csv")
#write.csv(changemonths_autumn_2491, "C:/Users/Documents/SPEI analysis/change files/changemonths_autumn_2491.csv")
#write.csv(changemonths_winter_2491, "C:/Users/Documents/SPEI analysis/change files/changemonths_winter_2491.csv")


########################################## Model output 2868 #########################################

#Import data
p_mod_2868<-read.csv("prcp_1980_2040_mod_12km_2868.csv",
                     header=F)
t_mod_2868<-read.csv("tas_1980_2040_mod_12km_2868.csv",
                     header=F)

#Reformat
mod_2868<-reformat(p_mod_2868, t_mod_2868)

#Change coordinates
mod_2868 <- lat_calc(mod_2868)

#Calculate bias
base_2868 <- past(mod_2868, obs)
mod_2868 <- bias(base_2868, mod_2868)

#Split into datasets by location
mod_2868_split <- split(mod_2868, list(mod_2868$easting, mod_2868$northing))

#Calculate SPEI 
mod_2868_spei<-spei_calc(mod_2868_split)


#Calculate number of drought events
spei_y_2868<-years(mod_2868_spei)
modpast_events_2868<-events_mod(spei_y_2868[["past"]])
modpresent_events_2868<-events_mod(spei_y_2868[["present"]])
modfuture_events_2868<-events_mod(spei_y_2868[["future"]])

#Save as .csv
#write.csv(modpast_events_2868, "C:/Users/Documents/SPEI analysis/actual files/events_modpast_2868_ex.csv")
write.csv(modpresent_events_2868, "events_modpresent_2868_ex.csv")
#write.csv(modfuture_events_2868, "C:/Users/Documents/SPEI analysis/actual files/events_modfuture_2868_ex.csv")

#Calculate number of drought events by season
spei_ps_2868<-period_season(mod_2868_spei)
modpast_events_spring_2868<-events_season(spei_ps_2868[["past.spring"]])
modpast_events_summer_2868<-events_season(spei_ps_2868[["past.summer"]])
modpast_events_autumn_2868<-events_season(spei_ps_2868[["past.autumn"]])
modpast_events_winter_2868<-events_season(spei_ps_2868[["past.winter"]])

modpresent_events_spring_2868<-events_season(spei_ps_2868[["present.spring"]])
modpresent_events_summer_2868<-events_season(spei_ps_2868[["present.summer"]])
modpresent_events_autumn_2868<-events_season(spei_ps_2868[["present.autumn"]])
modpresent_events_winter_2868<-events_season(spei_ps_2868[["present.winter"]])

modfuture_events_spring_2868<-events_season(spei_ps_2868[["future.spring"]])
modfuture_events_summer_2868<-events_season(spei_ps_2868[["future.summer"]])
modfuture_events_autumn_2868<-events_season(spei_ps_2868[["future.autumn"]])
modfuture_events_winter_2868<-events_season(spei_ps_2868[["future.winter"]])

#Save as .csv
#write.csv(modpast_events_spring_2868, "C:/Users/Documents/SPEI analysis/actual files/events_modpast_spring_2868_ex.csv")
#write.csv(modpast_events_summer_2868, "C:/Users/Documents/SPEI analysis/actual files/events_modpast_summer_2868_ex.csv")
#write.csv(modpast_events_autumn_2868, "C:/Users/Documents/SPEI analysis/actual files/events_modpast_autumn_2868_ex.csv")
#write.csv(modpast_events_winter_2868, "C:/Users/Documents/SPEI analysis/actual files/events_modpast_winter_2868_ex.csv")

#write.csv(modpresent_events_spring_2868, "events_modpresent_spring_2868_ex.csv")
#write.csv(modpresent_events_summer_2868, "events_modpresent_summer_2868_ex.csv")
#write.csv(modpresent_events_autumn_2868, "events_modpresent_autumn_2868_ex.csv")
#write.csv(modpresent_events_winter_2868, "events_modpresent_winter_2868_ex.csv")

#write.csv(modfuture_events_spring_2868, "C:/Users/Documents/SPEI analysis/actual files/events_modfuture_spring_2868_ex.csv")
#write.csv(modfuture_events_summer_2868, "C:/Users/Documents/SPEI analysis/actual files/events_modfuture_summer_2868_ex.csv")
#write.csv(modfuture_events_autumn_2868, "C:/Users/Documents/SPEI analysis/actual files/events_modfuture_autumn_2868_ex.csv")
#write.csv(modfuture_events_winter_2868, "C:/Users/Documents/SPEI analysis/actual files/events_modfuture_winter_2868_ex.csv")


#Calculate number of drought months overall
modpast_months_2868<-months_mod(spei_y_2868[["past"]])
modpresent_months_2868<-months_mod(spei_y_2868[["present"]])
modfuture_months_2868<-months_mod(spei_y_2868[["future"]])

#Save as .csv
#write.csv(modpast_months_2868, "C:/Users/Documents/SPEI analysis/actual files/months_mod_actual_past_2868.csv")
#write.csv(modpresent_months_2868, "months_mod_actual_present_2868.csv")
#write.csv(modfuture_months_2868, "C:/Users/Documents/SPEI analysis/actual files/months_mod_actual_future_2868.csv")


#Calculate number of drought months
spei_s_2868<-seasons(mod_2868_spei)
modpast_months_spring_2868<-months_mod(spei_s_2868[["past"]][["spring"]])
modpast_months_summer_2868<-months_mod(spei_s_2868[["past"]][["summer"]])
modpast_months_autumn_2868<-months_mod(spei_s_2868[["past"]][["autumn"]])
modpast_months_winter_2868<-months_mod(spei_s_2868[["past"]][["winter"]])

modpresent_months_spring_2868<-months_mod(spei_s_2868[["present"]][["spring"]])
modpresent_months_summer_2868<-months_mod(spei_s_2868[["present"]][["summer"]])
modpresent_months_autumn_2868<-months_mod(spei_s_2868[["present"]][["autumn"]])
modpresent_months_winter_2868<-months_mod(spei_s_2868[["present"]][["winter"]])

modfuture_months_spring_2868<-months_mod(spei_s_2868[["future"]][["spring"]])
modfuture_months_summer_2868<-months_mod(spei_s_2868[["future"]][["summer"]])
modfuture_months_autumn_2868<-months_mod(spei_s_2868[["future"]][["autumn"]])
modfuture_months_winter_2868<-months_mod(spei_s_2868[["future"]][["winter"]])

#Save as .csv
#write.csv(modpast_months_spring_2868, "C:/Users/Documents/SPEI analysis/actual files/months_modpast_spring_2868.csv")
#write.csv(modpast_months_summer_2868, "C:/Users/Documents/SPEI analysis/actual files/months_modpast_summer_2868.csv")
#write.csv(modpast_months_autumn_2868, "C:/Users/Documents/SPEI analysis/actual files/months_modpast_autumn_2868.csv")
#write.csv(modpast_months_winter_2868, "C:/Users/Documents/SPEI analysis/actual files/months_modpast_winter_2868.csv")

#write.csv(modpresent_months_spring_2868, "months_modpresent_spring_2868.csv")
#write.csv(modpresent_months_summer_2868, "months_modpresent_summer_2868.csv")
#write.csv(modpresent_months_autumn_2868, "months_modpresent_autumn_2868.csv")
#write.csv(modpresent_months_winter_2868, "months_modpresent_winter_2868.csv")

#write.csv(modfuture_months_spring_2868, "C:/Users/Documents/SPEI analysis/actual files/months_modfuture_spring_2868.csv")
#write.csv(modfuture_months_summer_2868, "C:/Users/Documents/SPEI analysis/actual files/months_modfuture_summer_2868.csv")
#write.csv(modfuture_months_autumn_2868, "C:/Users/Documents/SPEI analysis/actual files/months_modfuture_autumn_2868.csv")
#write.csv(modfuture_months_winter_2868, "C:/Users/Documents/SPEI analysis/actual files/months_modfuture_winter_2868.csv")


#Calculate change in number of drought events
changeevents_2868<-change(modpast_events_2868, modfuture_events_2868)

#Save as .csv
#write.csv(changeevents_2868, "C:/Users/Documents/SPEI analysis/change files/changeevents_2868_ex.csv")

#Calculate change in number of drought events seasonally
changeevents_spring_2868<-change(modpast_events_spring_2868, modfuture_events_spring_2868)
changeevents_summer_2868<-change(modpast_events_summer_2868, modfuture_events_summer_2868)
changeevents_autumn_2868<-change(modpast_events_autumn_2868, modfuture_events_autumn_2868)
changeevents_winter_2868<-change(modpast_events_winter_2868, modfuture_events_winter_2868)

#Save as .csv
#write.csv(changeevents_spring_2868, "C:/Users/Documents/SPEI analysis/change files/changeevents_spring_2868_ex.csv")
#write.csv(changeevents_summer_2868, "C:/Users/Documents/SPEI analysis/change files/changeevents_summer_2868_ex.csv")
#write.csv(changeevents_autumn_2868, "C:/Users/Documents/SPEI analysis/change files/changeevents_autumn_2868_ex.csv")
#write.csv(changeevents_winter_2868, "C:/Users/Documents/SPEI analysis/change files/changeevents_winter_2868_ex.csv")


#Calculate change in drought months
changemonths_2868<-change(modpast_months_2868, modfuture_months_2868)

#Save as .csv
#write.csv(changemonths_2868, "C:/Users/Documents/SPEI analysis/change files/changemonths_2868.csv")


#Calculate change in number of drought months seasonally
changemonths_spring_2868<-change(modpast_months_spring_2868, modfuture_months_spring_2868)
changemonths_summer_2868<-change(modpast_months_summer_2868, modfuture_months_summer_2868)
changemonths_autumn_2868<-change(modpast_months_autumn_2868, modfuture_months_autumn_2868)
changemonths_winter_2868<-change(modpast_months_winter_2868, modfuture_months_winter_2868)

#Save as .csv
#write.csv(changemonths_spring_2868, "C:/Users/Documents/SPEI analysis/change files/changemonths_spring_2868.csv")
#write.csv(changemonths_summer_2868, "C:/Users/Documents/SPEI analysis/change files/changemonths_summer_2868.csv")
#write.csv(changemonths_autumn_2868, "C:/Users/Documents/SPEI analysis/change files/changemonths_autumn_2868.csv")
#write.csv(changemonths_winter_2868, "C:/Users/Documents/SPEI analysis/change files/changemonths_winter_2868.csv")


########################################## Combine models #########################################

## Months

#Total
modmonths_total_future_comb<-combine(modfuture_months_0000, modfuture_months_1113, modfuture_months_1554,
                                     modfuture_months_1649, modfuture_months_1843, modfuture_months_1935,
                                     modfuture_months_2123, modfuture_months_2242, modfuture_months_2305,
                                     modfuture_months_2335, modfuture_months_2491, modfuture_months_2868)
write.csv(modmonths_total_future_comb, "months_mod_actual_future_comb.csv")

modmonths_total_present_comb<-combine(modpresent_months_0000, modpresent_months_1113, modpresent_months_1554,
                                     modpresent_months_1649, modpresent_months_1843, modpresent_months_1935,
                                     modpresent_months_2123, modpresent_months_2242, modpresent_months_2305,
                                     modpresent_months_2335, modpresent_months_2491, modpresent_months_2868)
write.csv(modmonths_total_present_comb, "months_mod_actual_present_comb.csv")

modmonths_total_past_comb<-combine(modpast_months_0000, modpast_months_1113, modpast_months_1554,
                                   modpast_months_1649, modpast_months_1843, modpast_months_1935,
                                   modpast_months_2123, modpast_months_2242, modpast_months_2305,
                                   modpast_months_2335, modpast_months_2491, modpast_months_2868)
write.csv(modmonths_total_past_comb, "months_mod_actual_past_comb.csv")


changemonths_comb<-combine(changemonths_0000,changemonths_1113,changemonths_1554,changemonths_1649,
                           changemonths_1843,changemonths_1935,changemonths_2123,changemonths_2242,
                           changemonths_2305,changemonths_2335,changemonths_2491,changemonths_2868)

write.csv(changemonths_comb, "changemonths_comb.csv")

#Autumn

modmonths_autumn_future_comb<-combine(modfuture_months_autumn_0000, modfuture_months_autumn_1113, modfuture_months_autumn_1554,
                          modfuture_months_autumn_1649, modfuture_months_autumn_1843, modfuture_months_autumn_1935,
                          modfuture_months_autumn_2123, modfuture_months_autumn_2242, modfuture_months_autumn_2305,
                          modfuture_months_autumn_2335, modfuture_months_autumn_2491, modfuture_months_autumn_2868)
write.csv(modmonths_autumn_future_comb, "modmonths_autumn_future_comb.csv")

modmonths_autumn_present_comb<-combine(modpresent_months_autumn_0000, modpresent_months_autumn_1113, modpresent_months_autumn_1554,
                                      modpresent_months_autumn_1649, modpresent_months_autumn_1843, modpresent_months_autumn_1935,
                                      modpresent_months_autumn_2123, modpresent_months_autumn_2242, modpresent_months_autumn_2305,
                                      modpresent_months_autumn_2335, modpresent_months_autumn_2491, modpresent_months_autumn_2868)
write.csv(modmonths_autumn_present_comb, "modmonths_autumn_present_comb.csv")

modmonths_autumn_past_comb<-combine(modpast_months_autumn_0000, modpast_months_autumn_1113, modpast_months_autumn_1554,
                             modpast_months_autumn_1649, modpast_months_autumn_1843, modpast_months_autumn_1935,
                             modpast_months_autumn_2123, modpast_months_autumn_2242, modpast_months_autumn_2305,
                             modpast_months_autumn_2335, modpast_months_autumn_2491, modpast_months_autumn_2868)
write.csv(modmonths_autumn_past_comb, "modmonths_autumn_past_comb.csv")


changemonths_autumn_comb<-combine(changemonths_autumn_0000,changemonths_autumn_1113,changemonths_autumn_1554,changemonths_autumn_1649,
                   changemonths_autumn_1843,changemonths_autumn_1935,changemonths_autumn_2123,changemonths_autumn_2242,
                   changemonths_autumn_2305,changemonths_autumn_2335,changemonths_autumn_2491,changemonths_autumn_2868)
write.csv(changemonths_autumn_comb, "changemonths_autumn_comb.csv")


#Winter

modmonths_winter_future_comb<-combine(modfuture_months_winter_0000, modfuture_months_winter_1113, modfuture_months_winter_1554,
                             modfuture_months_winter_1649, modfuture_months_winter_1843, modfuture_months_winter_1935,
                             modfuture_months_winter_2123, modfuture_months_winter_2242, modfuture_months_winter_2305,
                             modfuture_months_winter_2335, modfuture_months_winter_2491, modfuture_months_winter_2868)
write.csv(modmonths_winter_future_comb, "modmonths_winter_future_comb.csv")

modmonths_winter_present_comb<-combine(modpresent_months_winter_0000, modpresent_months_winter_1113, modpresent_months_winter_1554,
                                      modpresent_months_winter_1649, modpresent_months_winter_1843, modpresent_months_winter_1935,
                                      modpresent_months_winter_2123, modpresent_months_winter_2242, modpresent_months_winter_2305,
                                      modpresent_months_winter_2335, modpresent_months_winter_2491, modpresent_months_winter_2868)
write.csv(modmonths_winter_present_comb, "modmonths_winter_present_comb.csv")

modmonths_winter_past_comb<-combine(modpast_months_winter_0000, modpast_months_winter_1113, modpast_months_winter_1554,
                             modpast_months_winter_1649, modpast_months_winter_1843, modpast_months_winter_1935,
                             modpast_months_winter_2123, modpast_months_winter_2242, modpast_months_winter_2305,
                             modpast_months_winter_2335, modpast_months_winter_2491, modpast_months_winter_2868)
write.csv(modmonths_winter_past_comb, "modmonths_winter_past_comb.csv")


changemonths_winter_comb<-combine(changemonths_winter_0000,changemonths_winter_1113,changemonths_winter_1554,changemonths_winter_1649,
                                changemonths_winter_1843,changemonths_winter_1935,changemonths_winter_2123,changemonths_winter_2242,
                                changemonths_winter_2305,changemonths_winter_2335,changemonths_winter_2491,changemonths_winter_2868)
write.csv(changemonths_winter_comb, "changemonths_winter_comb.csv")


#Spring

modmonths_spring_future_comb<-combine(modfuture_months_spring_0000, modfuture_months_spring_1113, modfuture_months_spring_1554,
                             modfuture_months_spring_1649, modfuture_months_spring_1843, modfuture_months_spring_1935,
                             modfuture_months_spring_2123, modfuture_months_spring_2242, modfuture_months_spring_2305,
                             modfuture_months_spring_2335, modfuture_months_spring_2491, modfuture_months_spring_2868)
write.csv(modmonths_spring_future_comb, "modmonths_spring_future_comb.csv")

modmonths_spring_present_comb<-combine(modpresent_months_spring_0000, modpresent_months_spring_1113, modpresent_months_spring_1554,
                                      modpresent_months_spring_1649, modpresent_months_spring_1843, modpresent_months_spring_1935,
                                      modpresent_months_spring_2123, modpresent_months_spring_2242, modpresent_months_spring_2305,
                                      modpresent_months_spring_2335, modpresent_months_spring_2491, modpresent_months_spring_2868)
write.csv(modmonths_spring_present_comb, "modmonths_spring_present_comb.csv")

modmonths_spring_past_comb<-combine(modpast_months_spring_0000, modpast_months_spring_1113, modpast_months_spring_1554,
                             modpast_months_spring_1649, modpast_months_spring_1843, modpast_months_spring_1935,
                             modpast_months_spring_2123, modpast_months_spring_2242, modpast_months_spring_2305,
                             modpast_months_spring_2335, modpast_months_spring_2491, modpast_months_spring_2868)
write.csv(modmonths_spring_past_comb, "modmonths_spring_past_comb.csv")


changemonths_spring_comb<-combine(changemonths_spring_0000,changemonths_spring_1113,changemonths_spring_1554,changemonths_spring_1649,
                                changemonths_spring_1843,changemonths_spring_1935,changemonths_spring_2123,changemonths_spring_2242,
                                changemonths_spring_2305,changemonths_spring_2335,changemonths_spring_2491,changemonths_spring_2868)
write.csv(changemonths_spring_comb, "changemonths_spring_comb.csv")


#Summer

modmonths_summer_future_comb<-combine(modfuture_months_summer_0000, modfuture_months_summer_1113, modfuture_months_summer_1554,
                             modfuture_months_summer_1649, modfuture_months_summer_1843, modfuture_months_summer_1935,
                             modfuture_months_summer_2123, modfuture_months_summer_2242, modfuture_months_summer_2305,
                             modfuture_months_summer_2335, modfuture_months_summer_2491, modfuture_months_summer_2868)
write.csv(modmonths_summer_future_comb, "modmonths_summer_future_comb.csv")

modmonths_summer_present_comb<-combine(modpresent_months_summer_0000, modpresent_months_summer_1113, modpresent_months_summer_1554,
                                      modpresent_months_summer_1649, modpresent_months_summer_1843, modpresent_months_summer_1935,
                                      modpresent_months_summer_2123, modpresent_months_summer_2242, modpresent_months_summer_2305,
                                      modpresent_months_summer_2335, modpresent_months_summer_2491, modpresent_months_summer_2868)
write.csv(modmonths_summer_present_comb, "modmonths_summer_present_comb.csv")

modmonths_summer_past_comb<-combine(modpast_months_summer_0000, modpast_months_summer_1113, modpast_months_summer_1554,
                             modpast_months_summer_1649, modpast_months_summer_1843, modpast_months_summer_1935,
                             modpast_months_summer_2123, modpast_months_summer_2242, modpast_months_summer_2305,
                             modpast_months_summer_2335, modpast_months_summer_2491, modpast_months_summer_2868)
write.csv(modmonths_summer_past_comb, "modmonths_summer_past_comb.csv")


changemonths_summer_comb<-combine(changemonths_summer_0000,changemonths_summer_1113,changemonths_summer_1554,changemonths_summer_1649,
                                changemonths_summer_1843,changemonths_summer_1935,changemonths_summer_2123,changemonths_summer_2242,
                                changemonths_summer_2305,changemonths_summer_2335,changemonths_summer_2491,changemonths_summer_2868)
write.csv(changemonths_summer_comb, "changemonths_summer_comb.csv")



## Events


#Autumn

modevents_autumn_future_comb<-combine(modfuture_events_autumn_0000, modfuture_events_autumn_1113, modfuture_events_autumn_1554,
                             modfuture_events_autumn_1649, modfuture_events_autumn_1843, modfuture_events_autumn_1935,
                             modfuture_events_autumn_2123, modfuture_events_autumn_2242, modfuture_events_autumn_2305,
                             modfuture_events_autumn_2335, modfuture_events_autumn_2491, modfuture_events_autumn_2868)
write.csv(modevents_autumn_future_comb, "modevents_autumn_future_comb.csv")

modevents_autumn_present_comb<-combine(modpresent_events_autumn_0000, modpresent_events_autumn_1113, modpresent_events_autumn_1554,
                                      modpresent_events_autumn_1649, modpresent_events_autumn_1843, modpresent_events_autumn_1935,
                                      modpresent_events_autumn_2123, modpresent_events_autumn_2242, modpresent_events_autumn_2305,
                                      modpresent_events_autumn_2335, modpresent_events_autumn_2491, modpresent_events_autumn_2868)
write.csv(modevents_autumn_present_comb, "modevents_autumn_present_comb.csv")

modevents_autumn_past_comb<-combine(modpast_events_autumn_0000, modpast_events_autumn_1113, modpast_events_autumn_1554,
                                  modpast_events_autumn_1649, modpast_events_autumn_1843, modpast_events_autumn_1935,
                                  modpast_events_autumn_2123, modpast_events_autumn_2242, modpast_events_autumn_2305,
                                  modpast_events_autumn_2335, modpast_events_autumn_2491, modpast_events_autumn_2868)
write.csv(modevents_autumn_past_comb, "modevents_autumn_past_comb.csv")

changeevents_autumn_comb<-combine(changeevents_autumn_0000,changeevents_autumn_1113,changeevents_autumn_1554,changeevents_autumn_1649,
                                changeevents_autumn_1843,changeevents_autumn_1935,changeevents_autumn_2123,changeevents_autumn_2242,
                                changeevents_autumn_2305,changeevents_autumn_2335,changeevents_autumn_2491,changeevents_autumn_2868)
write.csv(changeevents_autumn_comb, "changeevents_autumn_comb.csv")


#Spring

modevents_spring_future_comb<-combine(modfuture_events_spring_0000, modfuture_events_spring_1113, modfuture_events_spring_1554,
                             modfuture_events_spring_1649, modfuture_events_spring_1843, modfuture_events_spring_1935,
                             modfuture_events_spring_2123, modfuture_events_spring_2242, modfuture_events_spring_2305,
                             modfuture_events_spring_2335, modfuture_events_spring_2491, modfuture_events_spring_2868)
write.csv(modevents_spring_future_comb, "modevents_spring_future_comb.csv")

modevents_spring_present_comb<-combine(modpresent_events_spring_0000, modpresent_events_spring_1113, modpresent_events_spring_1554,
                                      modpresent_events_spring_1649, modpresent_events_spring_1843, modpresent_events_spring_1935,
                                      modpresent_events_spring_2123, modpresent_events_spring_2242, modpresent_events_spring_2305,
                                      modpresent_events_spring_2335, modpresent_events_spring_2491, modpresent_events_spring_2868)
write.csv(modevents_spring_present_comb, "modevents_spring_present_comb.csv")

modevents_spring_past_comb<-combine(modpast_events_spring_0000, modpast_events_spring_1113, modpast_events_spring_1554,
                                  modpast_events_spring_1649, modpast_events_spring_1843, modpast_events_spring_1935,
                                  modpast_events_spring_2123, modpast_events_spring_2242, modpast_events_spring_2305,
                                  modpast_events_spring_2335, modpast_events_spring_2491, modpast_events_spring_2868)
write.csv(modevents_spring_past_comb, "modevents_spring_past_comb.csv")

changeevents_spring_comb<-combine(changeevents_spring_0000,changeevents_spring_1113,changeevents_spring_1554,changeevents_spring_1649,
                                changeevents_spring_1843,changeevents_spring_1935,changeevents_spring_2123,changeevents_spring_2242,
                                changeevents_spring_2305,changeevents_spring_2335,changeevents_spring_2491,changeevents_spring_2868)
write.csv(changeevents_spring_comb, "changeevents_spring_comb.csv")


#Summer

modevents_summer_future_comb<-combine(modfuture_events_summer_0000, modfuture_events_summer_1113, modfuture_events_summer_1554,
                             modfuture_events_summer_1649, modfuture_events_summer_1843, modfuture_events_summer_1935,
                             modfuture_events_summer_2123, modfuture_events_summer_2242, modfuture_events_summer_2305,
                             modfuture_events_summer_2335, modfuture_events_summer_2491, modfuture_events_summer_2868)
write.csv(modevents_summer_future_comb, "modevents_summer_future_comb.csv")

modevents_summer_present_comb<-combine(modpresent_events_summer_0000, modpresent_events_summer_1113, modpresent_events_summer_1554,
                                      modpresent_events_summer_1649, modpresent_events_summer_1843, modpresent_events_summer_1935,
                                      modpresent_events_summer_2123, modpresent_events_summer_2242, modpresent_events_summer_2305,
                                      modpresent_events_summer_2335, modpresent_events_summer_2491, modpresent_events_summer_2868)
write.csv(modevents_summer_present_comb, "modevents_summer_present_comb.csv")

modevents_summer_past_comb<-combine(modpast_events_summer_0000, modpast_events_summer_1113, modpast_events_summer_1554,
                                  modpast_events_summer_1649, modpast_events_summer_1843, modpast_events_summer_1935,
                                  modpast_events_summer_2123, modpast_events_summer_2242, modpast_events_summer_2305,
                                  modpast_events_summer_2335, modpast_events_summer_2491, modpast_events_summer_2868)
write.csv(modevents_summer_past_comb, "modevents_summer_past_comb.csv")

changeevents_summer_comb<-combine(changeevents_summer_0000,changeevents_summer_1113,changeevents_summer_1554,changeevents_summer_1649,
                                changeevents_summer_1843,changeevents_summer_1935,changeevents_summer_2123,changeevents_summer_2242,
                                changeevents_summer_2305,changeevents_summer_2335,changeevents_summer_2491,changeevents_summer_2868)
write.csv(changeevents_summer_comb, "changeevents_summer_comb.csv")


#Winter

modevents_winter_future_comb<-combine(modfuture_events_winter_0000, modfuture_events_winter_1113, modfuture_events_winter_1554,
                             modfuture_events_winter_1649, modfuture_events_winter_1843, modfuture_events_winter_1935,
                             modfuture_events_winter_2123, modfuture_events_winter_2242, modfuture_events_winter_2305,
                             modfuture_events_winter_2335, modfuture_events_winter_2491, modfuture_events_winter_2868)
write.csv(modevents_winter_future_comb, "modevents_winter_future_comb.csv")

modevents_winter_present_comb<-combine(modpresent_events_winter_0000, modpresent_events_winter_1113, modpresent_events_winter_1554,
                                      modpresent_events_winter_1649, modpresent_events_winter_1843, modpresent_events_winter_1935,
                                      modpresent_events_winter_2123, modpresent_events_winter_2242, modpresent_events_winter_2305,
                                      modpresent_events_winter_2335, modpresent_events_winter_2491, modpresent_events_winter_2868)
write.csv(modevents_winter_present_comb, "modevents_winter_present_comb.csv")

modevents_winter_past_comb<-combine(modpast_events_winter_0000, modpast_events_winter_1113, modpast_events_winter_1554,
                                  modpast_events_winter_1649, modpast_events_winter_1843, modpast_events_winter_1935,
                                  modpast_events_winter_2123, modpast_events_winter_2242, modpast_events_winter_2305,
                                  modpast_events_winter_2335, modpast_events_winter_2491, modpast_events_winter_2868)
write.csv(modevents_winter_past_comb, "modevents_winter_past_comb.csv")

changeevents_winter_comb<-combine(changeevents_winter_0000,changeevents_winter_1113,changeevents_winter_1554,changeevents_winter_1649,
                                changeevents_winter_1843,changeevents_winter_1935,changeevents_winter_2123,changeevents_winter_2242,
                                changeevents_winter_2305,changeevents_winter_2335,changeevents_winter_2491,changeevents_winter_2868)
write.csv(changeevents_winter_comb, "changeevents_winter_comb.csv")


#Total (all seasons)
modevents_past_comb<-combine(modpast_events_0000, modpast_events_1113, modpast_events_1554, 
                           modpast_events_1649, modpast_events_1843, modpast_events_1935,
                           modpast_events_2123, modpast_events_2242, modpast_events_2305,
                           modpast_events_2335, modpast_events_2491, modpast_events_2868)
write.csv(modevents_past_comb, "modevents_past_comb.csv")

modevents_present_comb<-combine(modpresent_events_0000, modpresent_events_1113, modpresent_events_1554, 
                             modpresent_events_1649, modpresent_events_1843, modpresent_events_1935,
                             modpresent_events_2123, modpresent_events_2242, modpresent_events_2305,
                             modpresent_events_2335, modpresent_events_2491, modpresent_events_2868)
write.csv(modevents_present_comb, "modevents_present_comb.csv")

modevents_future_comb<-combine(modfuture_events_0000, modfuture_events_1113, modfuture_events_1554, 
                           modfuture_events_1649, modfuture_events_1843, modfuture_events_1935,
                           modfuture_events_2123, modfuture_events_2242, modfuture_events_2305,
                           modfuture_events_2335, modfuture_events_2491, modfuture_events_2868)
write.csv(modevents_future_comb, "modevents_future_comb.csv")


#Change in events 
changeevents_comb<-combine(changeevents_0000,changeevents_1113,changeevents_1554,changeevents_1649,
                                changeevents_1843,changeevents_1935,changeevents_2123,changeevents_2242,
                                changeevents_2305,changeevents_2335,changeevents_2491,changeevents_2868)
write.csv(changeevents_comb, "changeevents_comb.csv")



############################################ Model likelihood ##########################################

## How many model members agree with the sign of the average?


## Months

#Autumn
changemonths_autumn_agree<-mod_agree_months(changemonths_autumn_0000, changemonths_autumn_1113, changemonths_autumn_1554, 
                                     changemonths_autumn_1649, changemonths_autumn_1843, changemonths_autumn_1935,
                                     changemonths_autumn_2123, changemonths_autumn_2242, changemonths_autumn_2305, 
                                     changemonths_autumn_2335, changemonths_autumn_2491, changemonths_autumn_2868,
                                     changemonths_autumn_comb)
#write.csv(changemonths_autumn_agree, "months_agree_change_autumn.csv")

#Spring
changemonths_spring_agree<-mod_agree_months(changemonths_spring_0000, changemonths_spring_1113, changemonths_spring_1554, 
                                     changemonths_spring_1649, changemonths_spring_1843, changemonths_spring_1935,
                                     changemonths_spring_2123, changemonths_spring_2242, changemonths_spring_2305, 
                                     changemonths_spring_2335, changemonths_spring_2491, changemonths_spring_2868,
                                     changemonths_spring_comb)
#write.csv(changemonths_spring_agree, "months_agree_change_spring.csv")

#Summer
changemonths_summer_agree<-mod_agree_months(changemonths_summer_0000, changemonths_summer_1113, changemonths_summer_1554, 
                                     changemonths_summer_1649, changemonths_summer_1843, changemonths_summer_1935,
                                     changemonths_summer_2123, changemonths_summer_2242, changemonths_summer_2305, 
                                     changemonths_summer_2335, changemonths_summer_2491, changemonths_summer_2868,
                                     changemonths_summer_comb)
#write.csv(changemonths_summer_agree, "months_agree_change_summer.csv")

#Winter
changemonths_winter_agree<-mod_agree_months(changemonths_winter_0000, changemonths_winter_1113, changemonths_winter_1554, 
                                     changemonths_winter_1649, changemonths_winter_1843, changemonths_winter_1935,
                                     changemonths_winter_2123, changemonths_winter_2242, changemonths_winter_2305, 
                                     changemonths_winter_2335, changemonths_winter_2491, changemonths_winter_2868,
                                     changemonths_winter_comb)
#write.csv(changemonths_winter_agree, "months_agree_change_winter.csv")

#Total
changemonths_total_agree<-mod_agree_months(changemonths_0000, changemonths_1113, changemonths_1554, 
                                    changemonths_1649, changemonths_1843, changemonths_1935,
                                    changemonths_2123, changemonths_2242, changemonths_2305, 
                                    changemonths_2335, changemonths_2491, changemonths_2868,
                                    changemonths_comb)

#write.csv(changemonths_total_agree, "months_agree_change.csv")


## Events

#Autumn
changeevents_autumn_agree<-mod_agree_events(changeevents_autumn_0000, changeevents_autumn_1113, changeevents_autumn_1554, 
                                     changeevents_autumn_1649, changeevents_autumn_1843, changeevents_autumn_1935,
                                     changeevents_autumn_2123, changeevents_autumn_2242, changeevents_autumn_2305, 
                                     changeevents_autumn_2335, changeevents_autumn_2491, changeevents_autumn_2868,
                                     changeevents_autumn_comb)
#write.csv(changeevents_autumn_agree, "events_agree_change_autumn.csv")

#Spring
changeevents_spring_agree<-mod_agree_events(changeevents_spring_0000, changeevents_spring_1113, changeevents_spring_1554, 
                                     changeevents_spring_1649, changeevents_spring_1843, changeevents_spring_1935,
                                     changeevents_spring_2123, changeevents_spring_2242, changeevents_spring_2305, 
                                     changeevents_spring_2335, changeevents_spring_2491, changeevents_spring_2868,
                                     changeevents_spring_comb)
#write.csv(changeevents_spring_agree, "events_agree_change_spring.csv")

#Summer
changeevents_summer_agree<-mod_agree_events(changeevents_summer_0000, changeevents_summer_1113, changeevents_summer_1554, 
                                     changeevents_summer_1649, changeevents_summer_1843, changeevents_summer_1935,
                                     changeevents_summer_2123, changeevents_summer_2242, changeevents_summer_2305, 
                                     changeevents_summer_2335, changeevents_summer_2491, changeevents_summer_2868,
                                     changeevents_summer_comb)
#write.csv(changeevents_summer_agree, "events_agree_change_summer.csv")

#Winter
changeevents_winter_agree<-mod_agree_events(changeevents_winter_0000, changeevents_winter_1113, changeevents_winter_1554, 
                                     changeevents_winter_1649, changeevents_winter_1843, changeevents_winter_1935,
                                     changeevents_winter_2123, changeevents_winter_2242, changeevents_winter_2305, 
                                     changeevents_winter_2335, changeevents_winter_2491, changeevents_winter_2868,
                                     changeevents_winter_comb)
#write.csv(changeevents_winter_agree, "events_agree_change_winter.csv")

#Total
changeevents_total_agree<-mod_agree_events(changeevents_0000, changeevents_1113, changeevents_1554, 
                                    changeevents_1649, changeevents_1843, changeevents_1935,
                                    changeevents_2123, changeevents_2242, changeevents_2305, 
                                    changeevents_2335, changeevents_2491, changeevents_2868,
                                    changeevents_comb)
#write.csv(changeevents_total_agree, "events_agree_change.csv")



## Standard deviation of the average of the 12 members ##


## Months

#Autumn
changemonths_autumn_sd<-stand_dev_months(changemonths_autumn_0000, changemonths_autumn_1113, changemonths_autumn_1554, 
                                  changemonths_autumn_1649, changemonths_autumn_1843, changemonths_autumn_1935,
                                  changemonths_autumn_2123, changemonths_autumn_2242, changemonths_autumn_2305, 
                                  changemonths_autumn_2335, changemonths_autumn_2491, changemonths_autumn_2868)

#write.csv(changemonths_autumn_sd, "months_sd_change_autumn_ex.csv")

#Spring
changemonths_spring_sd<-stand_dev_months(changemonths_spring_0000, changemonths_spring_1113, changemonths_spring_1554, 
                                  changemonths_spring_1649, changemonths_spring_1843, changemonths_spring_1935,
                                  changemonths_spring_2123, changemonths_spring_2242, changemonths_spring_2305, 
                                  changemonths_spring_2335, changemonths_spring_2491, changemonths_spring_2868)
#write.csv(changemonths_spring_sd, "months_sd_change_spring_ex.csv")

#Summer
changemonths_summer_sd<-stand_dev_months(changemonths_summer_0000, changemonths_summer_1113, changemonths_summer_1554, 
                                  changemonths_summer_1649, changemonths_summer_1843, changemonths_summer_1935,
                                  changemonths_summer_2123, changemonths_summer_2242, changemonths_summer_2305, 
                                  changemonths_summer_2335, changemonths_summer_2491, changemonths_summer_2868)
#write.csv(changemonths_summer_sd, "months_sd_change_summer_ex.csv")

#Winter
changemonths_winter_sd<-stand_dev_months(changemonths_winter_0000, changemonths_winter_1113, changemonths_winter_1554, 
                                  changemonths_winter_1649, changemonths_winter_1843, changemonths_winter_1935,
                                  changemonths_winter_2123, changemonths_winter_2242, changemonths_winter_2305, 
                                  changemonths_winter_2335, changemonths_winter_2491, changemonths_winter_2868)
#write.csv(changemonths_winter_sd, "months_sd_change_winter_ex.csv")


#Total
changemonths_total_sd<-stand_dev_months(changemonths_0000, changemonths_1113, changemonths_1554, 
                                 changemonths_1649, changemonths_1843, changemonths_1935,
                                 changemonths_2123, changemonths_2242, changemonths_2305, 
                                 changemonths_2335, changemonths_2491, changemonths_2868)
#write.csv(changemonths_total_sd, "months_sd_change_ex.csv")



## Events

#Autumn
changeevents_autumn_sd<-stand_dev_events(changeevents_autumn_0000, changeevents_autumn_1113, changeevents_autumn_1554, 
                                         changeevents_autumn_1649, changeevents_autumn_1843, changeevents_autumn_1935,
                                         changeevents_autumn_2123, changeevents_autumn_2242, changeevents_autumn_2305, 
                                         changeevents_autumn_2335, changeevents_autumn_2491, changeevents_autumn_2868)
#write.csv(changeevents_autumn_sd, "events_sd_change_autumn_ex.csv")

#Spring
changeevents_spring_sd<-stand_dev_events(changeevents_spring_0000, changeevents_spring_1113, changeevents_spring_1554, 
                                         changeevents_spring_1649, changeevents_spring_1843, changeevents_spring_1935,
                                         changeevents_spring_2123, changeevents_spring_2242, changeevents_spring_2305, 
                                         changeevents_spring_2335, changeevents_spring_2491, changeevents_spring_2868)
#write.csv(changeevents_spring_sd, "events_sd_change_spring_ex.csv")

#Summer
changeevents_summer_sd<-stand_dev_events(changeevents_summer_0000, changeevents_summer_1113, changeevents_summer_1554, 
                                         changeevents_summer_1649, changeevents_summer_1843, changeevents_summer_1935,
                                         changeevents_summer_2123, changeevents_summer_2242, changeevents_summer_2305, 
                                         changeevents_summer_2335, changeevents_summer_2491, changeevents_summer_2868)
#write.csv(changeevents_summer_sd, "events_sd_change_summer_ex.csv")

#Winter
changeevents_winter_sd<-stand_dev_events(changeevents_winter_0000, changeevents_winter_1113, changeevents_winter_1554, 
                                         changeevents_winter_1649, changeevents_winter_1843, changeevents_winter_1935,
                                         changeevents_winter_2123, changeevents_winter_2242, changeevents_winter_2305, 
                                         changeevents_winter_2335, changeevents_winter_2491, changeevents_winter_2868)
#write.csv(changeevents_winter_sd, "events_sd_change_winter_ex.csv")


#Total
changeevents_total_sd<-stand_dev_events(changeevents_0000, changeevents_1113, changeevents_1554, 
                                        changeevents_1649, changeevents_1843, changeevents_1935,
                                        changeevents_2123, changeevents_2242, changeevents_2305, 
                                        changeevents_2335, changeevents_2491, changeevents_2868)
#write.csv(changeevents_total_sd, "events_sd_change_ex.csv")


